/*
 * Copyright (c) 2017, Oracle and/or its affiliates.
 * Copyright (c) 2013, Regents of the University of California
 *
 * All rights reserved.
 */
package com.oracle.graal.python.shell;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import org.graalvm.launcher.AbstractLanguageLauncher;
import org.graalvm.options.OptionCategory;
import org.graalvm.polyglot.Context;
import org.graalvm.polyglot.Context.Builder;
import org.graalvm.polyglot.PolyglotException;
import org.graalvm.polyglot.PolyglotException.StackFrame;
import org.graalvm.polyglot.Source;
import org.graalvm.polyglot.SourceSection;

public class GraalPythonMain extends AbstractLanguageLauncher {
    public static void main(String[] args) {
        new GraalPythonMain().launch(args);
    }

    private ArrayList<String> programArgs = null;
    private String commandString = null;
    private String inputFile = null;

    @Override
    protected List<String> preprocessArguments(List<String> arguments, Map<String, String> polyglotOptions) {
        ArrayList<String> unrecognized = new ArrayList<>();
        programArgs = new ArrayList<>();
        for (int i = 0; i < arguments.size(); i++) {
            String arg = arguments.get(i);
            switch (arg) {
                case "-O":
                case "-OO":
                case "-B":
                    System.out.println("Warning: " + arg + " does nothing on GraalPython.");
                    break;
                case "-V":
                    unrecognized.add("--version");
                    break;
                case "-c":
                    i += 1;
                    if (i < arguments.size()) {
                        commandString = arguments.get(i);
                    } else {
                        print("Argument expected for the -c option");
                        printShortHelp();
                    }
                    break;
                case "-h":
                    unrecognized.add("--help");
                    break;
                default:
                    if (!arg.startsWith("-")) {
                        inputFile = arg;
                        programArgs.add(inputFile);
                        break;
                    } else {
                        unrecognized.add(arg);
                    }
            }
            if (inputFile != null || commandString != null) {
                i += 1;
                if (i < arguments.size()) {
                    programArgs.addAll(arguments.subList(i, arguments.size()));
                }
                break;
            }
        }
        if (inputFile == null && commandString == null) {
            print("No file or command argument found. Interactive mode is not implemented, yet.");
            unrecognized.add("--help");
        }
        return unrecognized;
    }

    private static void printShortHelp() {
        print("usage: python [option] ... [-c cmd | -m mod | file | -] [arg] ...\n" +
                        "Try `python -h' for more information.");
    }

    private static void print(String string) {
        System.out.println(string);
    }

    @Override
    protected void launch(Builder contextBuilder) {
        System.err.println("Please note: This Python implementation is in the very early stages, " +
                        "and can run little more than basic benchmarks at this point.");
        contextBuilder.arguments(getLanguageId(), programArgs.toArray(new String[0]));
        try (Context context = contextBuilder.build()) {
            Source src;
            if (commandString != null) {
                src = Source.newBuilder(getLanguageId(), commandString, "<string>").build();
            } else {
                assert inputFile != null;
                src = Source.newBuilder(getLanguageId(), new File(inputFile)).build();
            }
            try {
                context.eval(src);
            } catch (PolyglotException e) {
                // TODO: as soon as the traceback module works, we should switch
                // to executing the Python code for printing this
                ArrayList<String> stack = new ArrayList<>();
                for (StackFrame frame : e.getPolyglotStackTrace()) {
                    if (frame.isGuestFrame()) {
                        StringBuilder sb = new StringBuilder();
                        SourceSection sourceSection = frame.getSourceLocation();
                        String rootName = frame.getRootName();
                        if (sourceSection != null) {
                            sb.append("  ");
                            String path = sourceSection.getSource().getPath();
                            if (path != null) {
                                sb.append("File ");
                            }
                            sb.append('"');
                            sb.append(sourceSection.getSource().getName());
                            sb.append("\", line ");
                            sb.append(sourceSection.getStartLine());
                            sb.append(", in ");
                            sb.append(rootName);
                            stack.add(sb.toString());
                        }
                    }
                }
                System.err.println("Traceback (most recent call last):");
                ListIterator<String> listIterator = stack.listIterator(stack.size());
                while (listIterator.hasPrevious()) {
                    System.err.println(listIterator.previous());
                }
                System.err.println(e.getMessage());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected String getLanguageId() {
        return "python";
    }

    @Override
    protected void printHelp(OptionCategory maxCategory) {
        print("usage: python [option] ... (-c cmd | file) [arg] ...\n" +
                        "Options and arguments (and corresponding environment variables):\n" +
                        "-B     : don't write .py[co] files on import; also PYTHONDONTWRITEBYTECODE=x\n" +
                        "-c cmd : program passed in as string (terminates option list)\n" +
                        // "-d : debug output from parser; also PYTHONDEBUG=x\n" +
                        // "-E : ignore PYTHON* environment variables (such as PYTHONPATH)\n" +
                        "-h     : print this help message and exit (also --help)\n" +
                        // "-i : inspect interactively after running script; forces a prompt even\n"
                        // +
                        // " if stdin does not appear to be a terminal; also PYTHONINSPECT=x\n" +
                        // "-m mod : run library module as a script (terminates option list)\n" +
                        "-O     : optimize generated bytecode slightly; also PYTHONOPTIMIZE=x\n" +
                        "-OO    : remove doc-strings in addition to the -O optimizations\n" +
                        // "-R : use a pseudo-random salt to make hash() values of various types
                        // be\n" +
                        // " unpredictable between separate invocations of the interpreter, as\n" +
                        // " a defense against denial-of-service attacks\n" +
                        // "-Q arg : division options: -Qold (default), -Qwarn, -Qwarnall, -Qnew\n"
                        // +
                        // "-s : don't add user site directory to sys.path; also PYTHONNOUSERSITE\n"
                        // +
                        // "-S : don't imply 'import site' on initialization\n" +
                        // "-t : issue warnings about inconsistent tab usage (-tt: issue errors)\n"
                        // +
                        // "-u : unbuffered binary stdout and stderr; also PYTHONUNBUFFERED=x\n" +
                        // " see man page for details on internal buffering relating to '-u'\n" +
                        // "-v : verbose (trace import statements); also PYTHONVERBOSE=x\n" +
                        // " can be supplied multiple times to increase verbosity\n" +
                        "-V     : print the Python version number and exit (also --version)\n" +
                        // "-W arg : warning control; arg is
                        // action:message:category:module:lineno\n" +
                        // " also PYTHONWARNINGS=arg\n" +
                        // "-x : skip first line of source, allowing use of non-Unix forms of
                        // #!cmd\n" +
                        // "-3 : warn about Python 3.x incompatibilities that 2to3 cannot trivially
                        // fix\n" +
                        "file   : program read from script file\n" +
                        // "- : program read from stdin (default; interactive mode if a tty)\n" +
                        "arg ...: arguments passed to program in sys.argv[1:]\n" +
                        "\n" +
                        "Other environment variables:\n" +
                        "PYTHONSTARTUP: file executed on interactive startup (no default)\n" +
                        "PYTHONPATH   : ':'-separated list of directories prefixed to the\n" +
                        "               default module search path.  The result is sys.path.\n" +
                        "PYTHONHOME   : alternate <prefix> directory (or <prefix>:<exec_prefix>).\n" +
                        "               The default module search path uses <prefix>/pythonX.X.\n" +
                        "PYTHONCASEOK : ignore case in 'import' statements (Windows).\n" +
                        "PYTHONIOENCODING: Encoding[:errors] used for stdin/stdout/stderr.\n" +
                        "PYTHONHASHSEED: if this variable is set to 'random', the effect is the same\n" +
                        "   as specifying the -R option: a random value is used to seed the hashes of\n" +
                        "   str, bytes and datetime objects.  It can also be set to an integer\n" +
                        "   in the range [0,4294967295] to get hash values with a predictable seed.");
    }

    @Override
    protected String[] getDefaultLanguages() {
        return new String[]{getLanguageId(), "llvm"};
    }

    @Override
    protected void collectArguments(Set<String> options) {
        options.add("-c");
        options.add("-h");
    }
}
