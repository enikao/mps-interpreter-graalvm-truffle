/*
 * Copyright (c) 2017, 2017, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.oracle.graalvm.launcher;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.graalvm.polyglot.Engine;

public final class LegacyLauncher {

    public static void main(String[] args) throws NoSuchMethodException, SecurityException {
        String className = args[0];
        Method loadClassMethod = Engine.class.getDeclaredMethod("loadLanguageClass", String.class);
        try {
            loadClassMethod.setAccessible(true);
            Class<?> result = (Class<?>) loadClassMethod.invoke(null, className);
            result.getMethod("main", String[].class).invoke(null, (Object) Arrays.copyOfRange(args, 1, args.length));
        } catch (NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
