// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ArrayReadNode.class)
final class ArrayReadNodeGen extends ArrayReadNode {

    @CompilationFinal private int state_ = 1;
    @CompilationFinal private int exclude_;
    @CompilationFinal private NumberData number_cache;

    private ArrayReadNodeGen() {
    }

    @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
    @Override
    protected Object executeWithTarget(JavaObject arg0Value, Object arg1Value) {
        int state = state_;
        if ((state & 0b1110) != 0 /* is-active doNumber(JavaObject, Number, Class<? extends Number>) || doNumberGeneric(JavaObject, Number) || notArray(JavaObject, Number) */ && arg1Value instanceof Number) {
            Number arg1Value_ = (Number) arg1Value;
            if ((state & 0b10) != 0 /* is-active doNumber(JavaObject, Number, Class<? extends Number>) */ && (arg0Value.isArray())) {
                NumberData s1_ = number_cache;
                while (s1_ != null) {
                    if ((arg1Value_.getClass() == s1_.clazz_)) {
                        return doNumber(arg0Value, arg1Value_, s1_.clazz_);
                    }
                    s1_ = s1_.next_;
                }
            }
            if ((state & 0b100) != 0 /* is-active doNumberGeneric(JavaObject, Number) */) {
                if ((arg0Value.isArray())) {
                    return doNumberGeneric(arg0Value, arg1Value_);
                }
            }
            if ((state & 0b1000) != 0 /* is-active notArray(JavaObject, Number) */) {
                if ((!(arg0Value.isArray()))) {
                    return ArrayReadNode.notArray(arg0Value, arg1Value_);
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value);
    }

    private Object executeAndSpecialize(JavaObject arg0Value, Object arg1Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            int exclude = exclude_;
            if (arg1Value instanceof Number) {
                Number arg1Value_ = (Number) arg1Value;
                if ((exclude & 0b1) == 0 /* is-not-excluded doNumber(JavaObject, Number, Class<? extends Number>) */ && (arg0Value.isArray())) {
                    int count1_ = 0;
                    NumberData s1_ = number_cache;
                    if ((state & 0b10) != 0 /* is-active doNumber(JavaObject, Number, Class<? extends Number>) */) {
                        while (s1_ != null) {
                            if ((arg1Value_.getClass() == s1_.clazz_)) {
                                break;
                            }
                            s1_ = s1_.next_;
                            count1_++;
                        }
                    }
                    if (s1_ == null) {
                        {
                            Class<? extends Number> clazz = (arg1Value_.getClass());
                            if ((arg1Value_.getClass() == clazz) && count1_ < (3)) {
                                s1_ = new NumberData(number_cache, clazz);
                                this.number_cache = s1_;
                                this.state_ = state | 0b10 /* add-active doNumber(JavaObject, Number, Class<? extends Number>) */;
                            }
                        }
                    }
                    if (s1_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return doNumber(arg0Value, arg1Value_, s1_.clazz_);
                    }
                }
                if ((arg0Value.isArray())) {
                    this.exclude_ = exclude | 0b1 /* add-excluded doNumber(JavaObject, Number, Class<? extends Number>) */;
                    this.number_cache = null;
                    state = state & 0xfffffffd /* remove-active doNumber(JavaObject, Number, Class<? extends Number>) */;
                    this.state_ = state | 0b100 /* add-active doNumberGeneric(JavaObject, Number) */;
                    lock.unlock();
                    hasLock = false;
                    return doNumberGeneric(arg0Value, arg1Value_);
                }
                if ((!(arg0Value.isArray()))) {
                    this.state_ = state | 0b1000 /* add-active notArray(JavaObject, Number) */;
                    lock.unlock();
                    hasLock = false;
                    return ArrayReadNode.notArray(arg0Value, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0b1110) & ((state & 0b1110) - 1)) == 0 /* is-single-active  */) {
            NumberData s1_ = this.number_cache;
            if ((s1_ == null || s1_.next_ == null)) {
                return NodeCost.MONOMORPHIC;
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    public static ArrayReadNode create() {
        return new ArrayReadNodeGen();
    }

    @GeneratedBy(ArrayReadNode.class)
    private static final class NumberData {

        @CompilationFinal NumberData next_;
        final Class<? extends Number> clazz_;

        NumberData(NumberData next_, Class<? extends Number> clazz_) {
            this.next_ = next_;
            this.clazz_ = clazz_;
        }

    }
}
