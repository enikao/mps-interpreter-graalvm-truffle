// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import java.lang.reflect.Type;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ExecuteMethodNode.class)
final class ExecuteMethodNodeGen extends ExecuteMethodNode {

    @CompilationFinal private int state_ = 1;
    @CompilationFinal private int exclude_;
    @Child private FixedData fixed_cache;
    @Child private VarArgsData varArgs_cache;
    @Child private ToJavaNode singleUncached_toJavaNode_;
    @Child private OverloadedCachedData overloadedCached_cache;
    @Child private ToJavaNode overloadedUncached_toJavaNode_;

    private ExecuteMethodNodeGen() {
    }

    @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
    @Override
    public Object execute(JavaMethodDesc arg0Value, Object arg1Value, Object[] arg2Value, Object arg3Value) {
        int state = state_;
        if ((state & 0b111110) != 0 /* is-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) || doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) || doSingleUncached(SingleMethodDesc, Object, Object[], Object, ToJavaNode) || doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) || doOverloadedUncached(OverloadedMethodDesc, Object, Object[], Object, ToJavaNode) */) {
            if ((state & 0b1110) != 0 /* is-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) || doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) || doSingleUncached(SingleMethodDesc, Object, Object[], Object, ToJavaNode) */ && arg0Value instanceof SingleMethodDesc) {
                SingleMethodDesc arg0Value_ = (SingleMethodDesc) arg0Value;
                if ((state & 0b10) != 0 /* is-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) */ && (!(arg0Value_.isVarArgs()))) {
                    FixedData s1_ = fixed_cache;
                    while (s1_ != null) {
                        if ((arg0Value_ == s1_.cachedMethod_)) {
                            return doFixed(arg0Value_, arg1Value, arg2Value, arg3Value, s1_.cachedMethod_, s1_.types_, s1_.toJavaNodes_);
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state & 0b100) != 0 /* is-active doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */ && (arg0Value_.isVarArgs())) {
                    VarArgsData s2_ = varArgs_cache;
                    while (s2_ != null) {
                        if ((arg0Value_ == s2_.cachedMethod_)) {
                            return doVarArgs(arg0Value_, arg1Value, arg2Value, arg3Value, s2_.cachedMethod_, s2_.toJavaNode_);
                        }
                        s2_ = s2_.next_;
                    }
                }
                if ((state & 0b1000) != 0 /* is-active doSingleUncached(SingleMethodDesc, Object, Object[], Object, ToJavaNode) */) {
                    return doSingleUncached(arg0Value_, arg1Value, arg2Value, arg3Value, singleUncached_toJavaNode_);
                }
            }
            if ((state & 0b110000) != 0 /* is-active doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) || doOverloadedUncached(OverloadedMethodDesc, Object, Object[], Object, ToJavaNode) */ && arg0Value instanceof OverloadedMethodDesc) {
                OverloadedMethodDesc arg0Value_ = (OverloadedMethodDesc) arg0Value;
                if ((state & 0b10000) != 0 /* is-active doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */) {
                    OverloadedCachedData s4_ = overloadedCached_cache;
                    while (s4_ != null) {
                        if ((arg0Value_ == s4_.cachedMethod_) && (ExecuteMethodNode.checkArgTypes(arg2Value, s4_.cachedArgTypes_))) {
                            return doOverloadedCached(arg0Value_, arg1Value, arg2Value, arg3Value, s4_.cachedMethod_, s4_.cachedArgTypes_, s4_.toJavaNode_, s4_.overload_, s4_.types_);
                        }
                        s4_ = s4_.next_;
                    }
                }
                if ((state & 0b100000) != 0 /* is-active doOverloadedUncached(OverloadedMethodDesc, Object, Object[], Object, ToJavaNode) */) {
                    return doOverloadedUncached(arg0Value_, arg1Value, arg2Value, arg3Value, overloadedUncached_toJavaNode_);
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
    }

    private Object executeAndSpecialize(JavaMethodDesc arg0Value, Object arg1Value, Object[] arg2Value, Object arg3Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            int exclude = exclude_;
            if (arg0Value instanceof SingleMethodDesc) {
                SingleMethodDesc arg0Value_ = (SingleMethodDesc) arg0Value;
                if ((exclude & 0b1) == 0 /* is-not-excluded doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) */ && (!(arg0Value_.isVarArgs()))) {
                    int count1_ = 0;
                    FixedData s1_ = fixed_cache;
                    if ((state & 0b10) != 0 /* is-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) */) {
                        while (s1_ != null) {
                            if ((arg0Value_ == s1_.cachedMethod_)) {
                                break;
                            }
                            s1_ = s1_.next_;
                            count1_++;
                        }
                    }
                    if (s1_ == null) {
                        {
                            SingleMethodDesc cachedMethod = (arg0Value_);
                            // assert (arg0Value_ == cachedMethod);
                            if (count1_ < (3)) {
                                TypeAndClass<?>[] types = (ExecuteMethodNode.getTypes(arg0Value_, arg0Value_.getParameterCount()));
                                ToJavaNode[] toJavaNodes = (ExecuteMethodNode.createToJava(arg0Value_.getParameterCount()));
                                s1_ = new FixedData(fixed_cache, cachedMethod, types, toJavaNodes);
                                this.fixed_cache = super.insert(s1_);
                                this.state_ = state | 0b10 /* add-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]) */;
                            }
                        }
                    }
                    if (s1_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return doFixed(arg0Value_, arg1Value, arg2Value, arg3Value, s1_.cachedMethod_, s1_.types_, s1_.toJavaNodes_);
                    }
                }
                if ((exclude & 0b10) == 0 /* is-not-excluded doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */ && (arg0Value_.isVarArgs())) {
                    int count2_ = 0;
                    VarArgsData s2_ = varArgs_cache;
                    if ((state & 0b100) != 0 /* is-active doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */) {
                        while (s2_ != null) {
                            if ((arg0Value_ == s2_.cachedMethod_)) {
                                break;
                            }
                            s2_ = s2_.next_;
                            count2_++;
                        }
                    }
                    if (s2_ == null) {
                        {
                            SingleMethodDesc cachedMethod = (arg0Value_);
                            // assert (arg0Value_ == cachedMethod);
                            if (count2_ < (3)) {
                                ToJavaNode toJavaNode = (ToJavaNode.create());
                                s2_ = new VarArgsData(varArgs_cache, cachedMethod, toJavaNode);
                                this.varArgs_cache = super.insert(s2_);
                                this.state_ = state | 0b100 /* add-active doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */;
                            }
                        }
                    }
                    if (s2_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return doVarArgs(arg0Value_, arg1Value, arg2Value, arg3Value, s2_.cachedMethod_, s2_.toJavaNode_);
                    }
                }
                this.singleUncached_toJavaNode_ = super.insert((ToJavaNode.create()));
                this.exclude_ = exclude | 0b11 /* add-excluded doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]), doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */;
                this.fixed_cache = null;
                this.varArgs_cache = null;
                state = state & 0xfffffff9 /* remove-active doFixed(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, TypeAndClass<>[], ToJavaNode[]), doVarArgs(SingleMethodDesc, Object, Object[], Object, SingleMethodDesc, ToJavaNode) */;
                this.state_ = state | 0b1000 /* add-active doSingleUncached(SingleMethodDesc, Object, Object[], Object, ToJavaNode) */;
                lock.unlock();
                hasLock = false;
                return doSingleUncached(arg0Value_, arg1Value, arg2Value, arg3Value, singleUncached_toJavaNode_);
            }
            if (arg0Value instanceof OverloadedMethodDesc) {
                OverloadedMethodDesc arg0Value_ = (OverloadedMethodDesc) arg0Value;
                if ((exclude & 0b100) == 0 /* is-not-excluded doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */) {
                    int count4_ = 0;
                    OverloadedCachedData s4_ = overloadedCached_cache;
                    if ((state & 0b10000) != 0 /* is-active doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */) {
                        while (s4_ != null) {
                            if ((arg0Value_ == s4_.cachedMethod_) && (ExecuteMethodNode.checkArgTypes(arg2Value, s4_.cachedArgTypes_))) {
                                break;
                            }
                            s4_ = s4_.next_;
                            count4_++;
                        }
                    }
                    if (s4_ == null) {
                        {
                            OverloadedMethodDesc cachedMethod = (arg0Value_);
                            Type[] cachedArgTypes = (ExecuteMethodNode.getArgTypes(arg2Value));
                            // assert (arg0Value_ == cachedMethod);
                            if ((ExecuteMethodNode.checkArgTypes(arg2Value, cachedArgTypes)) && count4_ < (3)) {
                                ToJavaNode toJavaNode = (ToJavaNode.create());
                                SingleMethodDesc overload = (ExecuteMethodNode.selectOverload(arg0Value_, arg2Value, arg3Value, toJavaNode));
                                TypeAndClass<?>[] types = (ExecuteMethodNode.getTypes(overload, arg2Value.length));
                                s4_ = new OverloadedCachedData(overloadedCached_cache, cachedMethod, cachedArgTypes, toJavaNode, overload, types);
                                this.overloadedCached_cache = super.insert(s4_);
                                this.state_ = state | 0b10000 /* add-active doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */;
                            }
                        }
                    }
                    if (s4_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return doOverloadedCached(arg0Value_, arg1Value, arg2Value, arg3Value, s4_.cachedMethod_, s4_.cachedArgTypes_, s4_.toJavaNode_, s4_.overload_, s4_.types_);
                    }
                }
                this.overloadedUncached_toJavaNode_ = super.insert((ToJavaNode.create()));
                this.exclude_ = exclude | 0b100 /* add-excluded doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */;
                this.overloadedCached_cache = null;
                state = state & 0xffffffef /* remove-active doOverloadedCached(OverloadedMethodDesc, Object, Object[], Object, OverloadedMethodDesc, Type[], ToJavaNode, SingleMethodDesc, TypeAndClass<>[]) */;
                this.state_ = state | 0b100000 /* add-active doOverloadedUncached(OverloadedMethodDesc, Object, Object[], Object, ToJavaNode) */;
                lock.unlock();
                hasLock = false;
                return doOverloadedUncached(arg0Value_, arg1Value, arg2Value, arg3Value, overloadedUncached_toJavaNode_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null, null}, arg0Value, arg1Value, arg2Value, arg3Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0b111110) & ((state & 0b111110) - 1)) == 0 /* is-single-active  */) {
            FixedData s1_ = this.fixed_cache;
            VarArgsData s2_ = this.varArgs_cache;
            OverloadedCachedData s4_ = this.overloadedCached_cache;
            if ((s1_ == null || s1_.next_ == null) && (s2_ == null || s2_.next_ == null) && (s4_ == null || s4_.next_ == null)) {
                return NodeCost.MONOMORPHIC;
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    public static ExecuteMethodNode create() {
        return new ExecuteMethodNodeGen();
    }

    @GeneratedBy(ExecuteMethodNode.class)
    private static final class FixedData extends Node {

        @Child FixedData next_;
        final SingleMethodDesc cachedMethod_;
        @CompilationFinal(dimensions = 1) final TypeAndClass<?>[] types_;
        @Children final ToJavaNode[] toJavaNodes_;

        FixedData(FixedData next_, SingleMethodDesc cachedMethod_, TypeAndClass<?>[] types_, ToJavaNode[] toJavaNodes_) {
            this.next_ = next_;
            this.cachedMethod_ = cachedMethod_;
            this.types_ = types_;
            this.toJavaNodes_ = toJavaNodes_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(ExecuteMethodNode.class)
    private static final class VarArgsData extends Node {

        @Child VarArgsData next_;
        final SingleMethodDesc cachedMethod_;
        @Child ToJavaNode toJavaNode_;

        VarArgsData(VarArgsData next_, SingleMethodDesc cachedMethod_, ToJavaNode toJavaNode_) {
            this.next_ = next_;
            this.cachedMethod_ = cachedMethod_;
            this.toJavaNode_ = toJavaNode_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
    @GeneratedBy(ExecuteMethodNode.class)
    private static final class OverloadedCachedData extends Node {

        @Child OverloadedCachedData next_;
        final OverloadedMethodDesc cachedMethod_;
        @CompilationFinal(dimensions = 1) final Type[] cachedArgTypes_;
        @Child ToJavaNode toJavaNode_;
        final SingleMethodDesc overload_;
        @CompilationFinal(dimensions = 1) final TypeAndClass<?>[] types_;

        OverloadedCachedData(OverloadedCachedData next_, OverloadedMethodDesc cachedMethod_, Type[] cachedArgTypes_, ToJavaNode toJavaNode_, SingleMethodDesc overload_, TypeAndClass<?>[] types_) {
            this.next_ = next_;
            this.cachedMethod_ = cachedMethod_;
            this.cachedArgTypes_ = cachedArgTypes_;
            this.toJavaNode_ = toJavaNode_;
            this.overload_ = overload_;
            this.types_ = types_;
        }

        @Override
        public NodeCost getCost() {
            return NodeCost.NONE;
        }

    }
}
