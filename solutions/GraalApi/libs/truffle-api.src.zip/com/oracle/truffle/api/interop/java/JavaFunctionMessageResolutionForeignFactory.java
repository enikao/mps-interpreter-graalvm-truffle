// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.java.JavaFunctionMessageResolutionForeign.ExecuteSubNode;
import com.oracle.truffle.api.interop.java.JavaFunctionMessageResolutionForeign.IsExecutableSubNode;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.util.concurrent.locks.Lock;

@GeneratedBy(JavaFunctionMessageResolutionForeign.class)
final class JavaFunctionMessageResolutionForeignFactory {

    @GeneratedBy(ExecuteSubNode.class)
    static final class ExecuteSubNodeGen extends ExecuteSubNode {

        @CompilationFinal private int state_ = 1;

        private ExecuteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaFunctionObject, Object[]) */ && arg0Value instanceof JavaFunctionObject) {
                JavaFunctionObject arg0Value_ = (JavaFunctionObject) arg0Value;
                if (arg1Value instanceof Object[]) {
                    Object[] arg1Value_ = (Object[]) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaFunctionObject) {
                    JavaFunctionObject arg0Value_ = (JavaFunctionObject) arg0Value;
                    if (arg1Value instanceof Object[]) {
                        Object[] arg1Value_ = (Object[]) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaFunctionObject, Object[]) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ExecuteSubNode create() {
            return new ExecuteSubNodeGen();
        }

    }
    @GeneratedBy(IsExecutableSubNode.class)
    static final class IsExecutableSubNodeGen extends IsExecutableSubNode {

        @CompilationFinal private int state_ = 1;

        private IsExecutableSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaFunctionObject) */ && arg0Value instanceof JavaFunctionObject) {
                JavaFunctionObject arg0Value_ = (JavaFunctionObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaFunctionObject) {
                    JavaFunctionObject arg0Value_ = (JavaFunctionObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaFunctionObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsExecutableSubNode create() {
            return new IsExecutableSubNodeGen();
        }

    }
}
