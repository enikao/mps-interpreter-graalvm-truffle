// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.ForeignAccess;
import com.oracle.truffle.api.interop.InteropException;
import com.oracle.truffle.api.interop.Message;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.interop.UnsupportedMessageException;
import com.oracle.truffle.api.interop.java.JavaInteropReflect.InvokeAndReadExecNode;
import com.oracle.truffle.api.interop.java.JavaInteropReflect.MethodNode;
import com.oracle.truffle.api.nodes.DirectCallNode;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import java.util.concurrent.locks.Lock;

@GeneratedBy(JavaInteropReflect.class)
final class JavaInteropReflectFactory {

    @GeneratedBy(MethodNode.class)
    static final class MethodNodeGen extends MethodNode {

        @CompilationFinal private int state_ = 1;
        @Child private CachedData cached_cache;

        private MethodNodeGen(String name, Message message, TypeAndClass<?> returnType) {
            super(name, message, returnType);
        }

        @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
        @Override
        protected Object executeImpl(TruffleObject arg0Value, Object[] arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active doCached(TruffleObject, Object[], ForeignAccess, DirectCallNode, Node) || doGeneric(TruffleObject, Object[]) */) {
                if ((state & 0b10) != 0 /* is-active doCached(TruffleObject, Object[], ForeignAccess, DirectCallNode, Node) */) {
                    CachedData s1_ = cached_cache;
                    while (s1_ != null) {
                        if ((MethodNode.acceptCached(arg0Value, s1_.foreignAccess_, s1_.canHandleCall_))) {
                            return doCached(arg0Value, arg1Value, s1_.foreignAccess_, s1_.canHandleCall_, s1_.messageNode_);
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state & 0b100) != 0 /* is-active doGeneric(TruffleObject, Object[]) */) {
                    return doGeneric(arg0Value, arg1Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(TruffleObject arg0Value, Object[] arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                int count1_ = 0;
                CachedData s1_ = cached_cache;
                if ((state & 0b10) != 0 /* is-active doCached(TruffleObject, Object[], ForeignAccess, DirectCallNode, Node) */) {
                    while (s1_ != null) {
                        if ((MethodNode.acceptCached(arg0Value, s1_.foreignAccess_, s1_.canHandleCall_))) {
                            break;
                        }
                        s1_ = s1_.next_;
                        count1_++;
                    }
                }
                if (s1_ == null) {
                    {
                        ForeignAccess foreignAccess = (arg0Value.getForeignAccess());
                        DirectCallNode canHandleCall = (MethodNode.createInlinedCallNode(createCanHandleTarget(foreignAccess)));
                        if ((MethodNode.acceptCached(arg0Value, foreignAccess, canHandleCall)) && count1_ < (8)) {
                            Node messageNode = (createNode(arg1Value));
                            s1_ = new CachedData(cached_cache, foreignAccess, canHandleCall, messageNode);
                            this.cached_cache = super.insert(s1_);
                            this.state_ = state | 0b10 /* add-active doCached(TruffleObject, Object[], ForeignAccess, DirectCallNode, Node) */;
                        }
                    }
                }
                if (s1_ != null) {
                    lock.unlock();
                    hasLock = false;
                    return doCached(arg0Value, arg1Value, s1_.foreignAccess_, s1_.canHandleCall_, s1_.messageNode_);
                }
                this.state_ = state | 0b100 /* add-active doGeneric(TruffleObject, Object[]) */;
                lock.unlock();
                hasLock = false;
                return doGeneric(arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                CachedData s1_ = this.cached_cache;
                if ((s1_ == null || s1_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        public static MethodNode create(String name, Message message, TypeAndClass<?> returnType) {
            return new MethodNodeGen(name, message, returnType);
        }

        @GeneratedBy(MethodNode.class)
        private static final class CachedData extends Node {

            @Child CachedData next_;
            final ForeignAccess foreignAccess_;
            @Child DirectCallNode canHandleCall_;
            @Child Node messageNode_;

            CachedData(CachedData next_, ForeignAccess foreignAccess_, DirectCallNode canHandleCall_, Node messageNode_) {
                this.next_ = next_;
                this.foreignAccess_ = foreignAccess_;
                this.canHandleCall_ = canHandleCall_;
                this.messageNode_ = messageNode_;
            }

            @Override
            public NodeCost getCost() {
                return NodeCost.NONE;
            }

        }
    }
    @GeneratedBy(InvokeAndReadExecNode.class)
    static final class InvokeAndReadExecNodeGen extends InvokeAndReadExecNode {

        @CompilationFinal private int state_ = 1;
        @CompilationFinal private int exclude_;

        private InvokeAndReadExecNodeGen(TypeAndClass<?> returnType, int arity) {
            super(returnType, arity);
        }

        @Override
        Object executeDispatch(TruffleObject arg0Value, String arg1Value, Object[] arg2Value) {
            int state = state_;
            if ((state & 0b1110) != 0 /* is-active doInvoke(TruffleObject, String, Object[]) || doReadExec(TruffleObject, String, Object[]) || doBoth(TruffleObject, String, Object[]) */) {
                if ((state & 0b10) != 0 /* is-active doInvoke(TruffleObject, String, Object[]) */) {
                    try {
                        return doInvoke(arg0Value, arg1Value, arg2Value);
                    } catch (InteropException ex) {
                        CompilerDirectives.transferToInterpreterAndInvalidate();
                        Lock lock = getLock();
                        lock.lock();
                        try {
                            this.exclude_ = this.exclude_ | 0b1 /* add-excluded doInvoke(TruffleObject, String, Object[]) */;
                            this.state_ = this.state_ & 0xfffffffd /* remove-active doInvoke(TruffleObject, String, Object[]) */;
                        } finally {
                            lock.unlock();
                        }
                        return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((state & 0b100) != 0 /* is-active doReadExec(TruffleObject, String, Object[]) */) {
                    try {
                        return doReadExec(arg0Value, arg1Value, arg2Value);
                    } catch (UnsupportedMessageException ex) {
                        CompilerDirectives.transferToInterpreterAndInvalidate();
                        Lock lock = getLock();
                        lock.lock();
                        try {
                            this.exclude_ = this.exclude_ | 0b10 /* add-excluded doReadExec(TruffleObject, String, Object[]) */;
                            this.state_ = this.state_ & 0xfffffffb /* remove-active doReadExec(TruffleObject, String, Object[]) */;
                        } finally {
                            lock.unlock();
                        }
                        return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((state & 0b1000) != 0 /* is-active doBoth(TruffleObject, String, Object[]) */) {
                    return doBoth(arg0Value, arg1Value, arg2Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(TruffleObject arg0Value, String arg1Value, Object[] arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                int exclude = exclude_;
                if ((exclude & 0b1) == 0 /* is-not-excluded doInvoke(TruffleObject, String, Object[]) */) {
                    this.state_ = state | 0b10 /* add-active doInvoke(TruffleObject, String, Object[]) */;
                    try {
                        lock.unlock();
                        hasLock = false;
                        return doInvoke(arg0Value, arg1Value, arg2Value);
                    } catch (InteropException ex) {
                        CompilerDirectives.transferToInterpreterAndInvalidate();
                        lock.lock();
                        try {
                            this.exclude_ = this.exclude_ | 0b1 /* add-excluded doInvoke(TruffleObject, String, Object[]) */;
                            this.state_ = this.state_ & 0xfffffffd /* remove-active doInvoke(TruffleObject, String, Object[]) */;
                        } finally {
                            lock.unlock();
                        }
                        return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
                    }
                }
                if ((exclude & 0b10) == 0 /* is-not-excluded doReadExec(TruffleObject, String, Object[]) */) {
                    this.state_ = state | 0b100 /* add-active doReadExec(TruffleObject, String, Object[]) */;
                    try {
                        lock.unlock();
                        hasLock = false;
                        return doReadExec(arg0Value, arg1Value, arg2Value);
                    } catch (UnsupportedMessageException ex) {
                        CompilerDirectives.transferToInterpreterAndInvalidate();
                        lock.lock();
                        try {
                            this.exclude_ = this.exclude_ | 0b10 /* add-excluded doReadExec(TruffleObject, String, Object[]) */;
                            this.state_ = this.state_ & 0xfffffffb /* remove-active doReadExec(TruffleObject, String, Object[]) */;
                        } finally {
                            lock.unlock();
                        }
                        return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
                    }
                }
                this.state_ = state | 0b1000 /* add-active doBoth(TruffleObject, String, Object[]) */;
                lock.unlock();
                hasLock = false;
                return doBoth(arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b1110) & ((state & 0b1110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static InvokeAndReadExecNode create(TypeAndClass<?> returnType, int arity) {
            return new InvokeAndReadExecNodeGen(returnType, arity);
        }

    }
}
