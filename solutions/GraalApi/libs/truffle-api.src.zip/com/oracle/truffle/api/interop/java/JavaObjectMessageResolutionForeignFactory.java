// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.ArrayGetSizeSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.ArrayHasSizeSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.BoxedCheckSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.ExecuteObjectSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.HasKeysSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.InvokeSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.IsExecutableObjectSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.IsInstantiableObjectSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.NewSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.NullCheckSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.PropertiesSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.PropertyInfoSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.ReadFieldSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.UnboxSubNode;
import com.oracle.truffle.api.interop.java.JavaObjectMessageResolutionForeign.WriteFieldSubNode;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.util.concurrent.locks.Lock;

@GeneratedBy(JavaObjectMessageResolutionForeign.class)
final class JavaObjectMessageResolutionForeignFactory {

    @GeneratedBy(ExecuteObjectSubNode.class)
    static final class ExecuteObjectSubNodeGen extends ExecuteObjectSubNode {

        @CompilationFinal private int state_ = 1;

        private ExecuteObjectSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, Object[]) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if (arg1Value instanceof Object[]) {
                    Object[] arg1Value_ = (Object[]) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof Object[]) {
                        Object[] arg1Value_ = (Object[]) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, Object[]) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ExecuteObjectSubNode create() {
            return new ExecuteObjectSubNodeGen();
        }

    }
    @GeneratedBy(WriteFieldSubNode.class)
    static final class WriteFieldSubNodeGen extends WriteFieldSubNode {

        @CompilationFinal private int state_ = 1;

        private WriteFieldSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(JavaObject, String, Object) || accessWithTarget(JavaObject, Number, Object) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, String, Object) */ && arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(JavaObject, Number, Object) */ && arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, String, Object) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                    }
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(JavaObject, Number, Object) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static WriteFieldSubNode create() {
            return new WriteFieldSubNodeGen();
        }

    }
    @GeneratedBy(NewSubNode.class)
    static final class NewSubNodeGen extends NewSubNode {

        @CompilationFinal private int state_ = 1;

        private NewSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, Object[]) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if (arg1Value instanceof Object[]) {
                    Object[] arg1Value_ = (Object[]) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof Object[]) {
                        Object[] arg1Value_ = (Object[]) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, Object[]) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static NewSubNode create() {
            return new NewSubNodeGen();
        }

    }
    @GeneratedBy(InvokeSubNode.class)
    static final class InvokeSubNodeGen extends InvokeSubNode {

        @CompilationFinal private int state_ = 1;

        private InvokeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, String, Object[]) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Object[]) {
                        Object[] arg2Value_ = (Object[]) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Object[]) {
                            Object[] arg2Value_ = (Object[]) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, String, Object[]) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static InvokeSubNode create() {
            return new InvokeSubNodeGen();
        }

    }
    @GeneratedBy(ReadFieldSubNode.class)
    static final class ReadFieldSubNodeGen extends ReadFieldSubNode {

        @CompilationFinal private int state_ = 1;

        private ReadFieldSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(JavaObject, Number) || accessWithTarget(JavaObject, String) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, Number) */ && arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(JavaObject, String) */ && arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, Number) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(JavaObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static ReadFieldSubNode create() {
            return new ReadFieldSubNodeGen();
        }

    }
    @GeneratedBy(PropertiesSubNode.class)
    static final class PropertiesSubNodeGen extends PropertiesSubNode {

        @CompilationFinal private int state_ = 1;

        private PropertiesSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, boolean) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if (arg1Value instanceof Boolean) {
                    boolean arg1Value_ = (boolean) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof Boolean) {
                        boolean arg1Value_ = (boolean) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, boolean) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static PropertiesSubNode create() {
            return new PropertiesSubNodeGen();
        }

    }
    @GeneratedBy(NullCheckSubNode.class)
    static final class NullCheckSubNodeGen extends NullCheckSubNode {

        @CompilationFinal private int state_ = 1;

        private NullCheckSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static NullCheckSubNode create() {
            return new NullCheckSubNodeGen();
        }

    }
    @GeneratedBy(UnboxSubNode.class)
    static final class UnboxSubNodeGen extends UnboxSubNode {

        @CompilationFinal private int state_ = 1;

        private UnboxSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static UnboxSubNode create() {
            return new UnboxSubNodeGen();
        }

    }
    @GeneratedBy(BoxedCheckSubNode.class)
    static final class BoxedCheckSubNodeGen extends BoxedCheckSubNode {

        @CompilationFinal private int state_ = 1;

        private BoxedCheckSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static BoxedCheckSubNode create() {
            return new BoxedCheckSubNodeGen();
        }

    }
    @GeneratedBy(IsExecutableObjectSubNode.class)
    static final class IsExecutableObjectSubNodeGen extends IsExecutableObjectSubNode {

        @CompilationFinal private int state_ = 1;

        private IsExecutableObjectSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsExecutableObjectSubNode create() {
            return new IsExecutableObjectSubNodeGen();
        }

    }
    @GeneratedBy(ArrayGetSizeSubNode.class)
    static final class ArrayGetSizeSubNodeGen extends ArrayGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ArrayGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ArrayGetSizeSubNode create() {
            return new ArrayGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(ArrayHasSizeSubNode.class)
    static final class ArrayHasSizeSubNodeGen extends ArrayHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ArrayHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ArrayHasSizeSubNode create() {
            return new ArrayHasSizeSubNodeGen();
        }

    }
    @GeneratedBy(IsInstantiableObjectSubNode.class)
    static final class IsInstantiableObjectSubNodeGen extends IsInstantiableObjectSubNode {

        @CompilationFinal private int state_ = 1;

        private IsInstantiableObjectSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsInstantiableObjectSubNode create() {
            return new IsInstantiableObjectSubNodeGen();
        }

    }
    @GeneratedBy(PropertyInfoSubNode.class)
    static final class PropertyInfoSubNodeGen extends PropertyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private PropertyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(JavaObject, Number) || accessWithTarget(JavaObject, String) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject, Number) */ && arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(JavaObject, String) */ && arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject, Number) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(JavaObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static PropertyInfoSubNode create() {
            return new PropertyInfoSubNodeGen();
        }

    }
    @GeneratedBy(HasKeysSubNode.class)
    static final class HasKeysSubNodeGen extends HasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private HasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(JavaObject) */ && arg0Value instanceof JavaObject) {
                JavaObject arg0Value_ = (JavaObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof JavaObject) {
                    JavaObject arg0Value_ = (JavaObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(JavaObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static HasKeysSubNode create() {
            return new HasKeysSubNodeGen();
        }

    }
}
