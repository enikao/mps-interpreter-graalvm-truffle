// CheckStyle: start generated
package com.oracle.truffle.api.interop.java;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ToJavaNode.class)
final class ToJavaNodeGen extends ToJavaNode {

    @CompilationFinal private int state_ = 1;
    @CompilationFinal private int exclude_;
    @CompilationFinal private CachedData cached_cache;

    private ToJavaNodeGen() {
    }

    @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
    @Override
    public Object execute(Object arg0Value, TypeAndClass<?> arg1Value, Object arg2Value) {
        int state = state_;
        if ((state & 0b1110) != 0 /* is-active doNull(Object, TypeAndClass<>, Object) || doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) || doGeneric(Object, TypeAndClass<>, Object) */) {
            if ((state & 0b10) != 0 /* is-active doNull(Object, TypeAndClass<>, Object) */) {
                if ((arg0Value == null)) {
                    return doNull(arg0Value, arg1Value, arg2Value);
                }
            }
            if ((state & 0b100) != 0 /* is-active doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */ && (arg0Value != null)) {
                CachedData s2_ = cached_cache;
                while (s2_ != null) {
                    if ((arg0Value.getClass() == s2_.cachedOperandType_) && (arg1Value == s2_.cachedTargetType_)) {
                        return doCached(arg0Value, arg1Value, arg2Value, s2_.cachedOperandType_, s2_.cachedTargetType_);
                    }
                    s2_ = s2_.next_;
                }
            }
            if ((state & 0b1000) != 0 /* is-active doGeneric(Object, TypeAndClass<>, Object) */) {
                if ((arg0Value != null)) {
                    return doGeneric(arg0Value, arg1Value, arg2Value);
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
    }

    private Object executeAndSpecialize(Object arg0Value, TypeAndClass<?> arg1Value, Object arg2Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            int exclude = exclude_;
            if ((arg0Value == null)) {
                this.state_ = state | 0b10 /* add-active doNull(Object, TypeAndClass<>, Object) */;
                lock.unlock();
                hasLock = false;
                return doNull(arg0Value, arg1Value, arg2Value);
            }
            if ((exclude & 0b1) == 0 /* is-not-excluded doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */ && (arg0Value != null)) {
                int count2_ = 0;
                CachedData s2_ = cached_cache;
                if ((state & 0b100) != 0 /* is-active doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */) {
                    while (s2_ != null) {
                        if ((arg0Value.getClass() == s2_.cachedOperandType_) && (arg1Value == s2_.cachedTargetType_)) {
                            break;
                        }
                        s2_ = s2_.next_;
                        count2_++;
                    }
                }
                if (s2_ == null) {
                    {
                        Class<?> cachedOperandType = (arg0Value.getClass());
                        if ((arg0Value.getClass() == cachedOperandType)) {
                            TypeAndClass<?> cachedTargetType = (arg1Value);
                            // assert (arg1Value == cachedTargetType);
                            if (count2_ < (3)) {
                                s2_ = new CachedData(cached_cache, cachedOperandType, cachedTargetType);
                                this.cached_cache = s2_;
                                this.state_ = state | 0b100 /* add-active doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */;
                            }
                        }
                    }
                }
                if (s2_ != null) {
                    lock.unlock();
                    hasLock = false;
                    return doCached(arg0Value, arg1Value, arg2Value, s2_.cachedOperandType_, s2_.cachedTargetType_);
                }
            }
            if ((arg0Value != null)) {
                this.exclude_ = exclude | 0b1 /* add-excluded doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */;
                this.cached_cache = null;
                state = state & 0xfffffffb /* remove-active doCached(Object, TypeAndClass<>, Object, Class<>, TypeAndClass<>) */;
                this.state_ = state | 0b1000 /* add-active doGeneric(Object, TypeAndClass<>, Object) */;
                lock.unlock();
                hasLock = false;
                return doGeneric(arg0Value, arg1Value, arg2Value);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0b1110) & ((state & 0b1110) - 1)) == 0 /* is-single-active  */) {
            CachedData s2_ = this.cached_cache;
            if ((s2_ == null || s2_.next_ == null)) {
                return NodeCost.MONOMORPHIC;
            }
        }
        return NodeCost.POLYMORPHIC;
    }

    public static ToJavaNode create() {
        return new ToJavaNodeGen();
    }

    @GeneratedBy(ToJavaNode.class)
    private static final class CachedData {

        @CompilationFinal CachedData next_;
        final Class<?> cachedOperandType_;
        final TypeAndClass<?> cachedTargetType_;

        CachedData(CachedData next_, Class<?> cachedOperandType_, TypeAndClass<?> cachedTargetType_) {
            this.next_ = next_;
            this.cachedOperandType_ = cachedOperandType_;
            this.cachedTargetType_ = cachedTargetType_;
        }

    }
}
