// CheckStyle: start generated
package com.oracle.truffle.api.metadata;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.metadata.DefaultScopeVariables.VariableNamesObject;
import com.oracle.truffle.api.metadata.VariableNamesMessageResolutionForeign.VarNamesGetSizeSubNode;
import com.oracle.truffle.api.metadata.VariableNamesMessageResolutionForeign.VarNamesHasSizeSubNode;
import com.oracle.truffle.api.metadata.VariableNamesMessageResolutionForeign.VarNamesReadSubNode;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.util.concurrent.locks.Lock;

@GeneratedBy(VariableNamesMessageResolutionForeign.class)
final class VariableNamesMessageResolutionForeignFactory {

    @GeneratedBy(VarNamesReadSubNode.class)
    static final class VarNamesReadSubNodeGen extends VarNamesReadSubNode {

        @CompilationFinal private int state_ = 1;

        private VarNamesReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariableNamesObject, int) */ && arg0Value instanceof VariableNamesObject) {
                VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                if (arg1Value instanceof Integer) {
                    int arg1Value_ = (int) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariableNamesObject) {
                    VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                    if (arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(VariableNamesObject, int) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarNamesReadSubNode create() {
            return new VarNamesReadSubNodeGen();
        }

    }
    @GeneratedBy(VarNamesGetSizeSubNode.class)
    static final class VarNamesGetSizeSubNodeGen extends VarNamesGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private VarNamesGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariableNamesObject) */ && arg0Value instanceof VariableNamesObject) {
                VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariableNamesObject) {
                    VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(VariableNamesObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarNamesGetSizeSubNode create() {
            return new VarNamesGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(VarNamesHasSizeSubNode.class)
    static final class VarNamesHasSizeSubNodeGen extends VarNamesHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private VarNamesHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariableNamesObject) */ && arg0Value instanceof VariableNamesObject) {
                VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariableNamesObject) {
                    VariableNamesObject arg0Value_ = (VariableNamesObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(VariableNamesObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarNamesHasSizeSubNode create() {
            return new VarNamesHasSizeSubNodeGen();
        }

    }
}
