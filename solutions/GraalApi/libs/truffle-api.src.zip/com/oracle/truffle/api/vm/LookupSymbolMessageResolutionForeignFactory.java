// CheckStyle: start generated
package com.oracle.truffle.api.vm;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.vm.DefaultScope.LookupSymbolGlobalObject;
import com.oracle.truffle.api.vm.LookupSymbolMessageResolutionForeign.SymbolsHasKeysSubNode;
import com.oracle.truffle.api.vm.LookupSymbolMessageResolutionForeign.SymbolsKeyInfoSubNode;
import com.oracle.truffle.api.vm.LookupSymbolMessageResolutionForeign.SymbolsKeysSubNode;
import com.oracle.truffle.api.vm.LookupSymbolMessageResolutionForeign.SymbolsReadSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(LookupSymbolMessageResolutionForeign.class)
final class LookupSymbolMessageResolutionForeignFactory {

    @GeneratedBy(SymbolsKeyInfoSubNode.class)
    static final class SymbolsKeyInfoSubNodeGen extends SymbolsKeyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private SymbolsKeyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LookupSymbolGlobalObject, String) */ && arg0Value instanceof LookupSymbolGlobalObject) {
                LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LookupSymbolGlobalObject) {
                    LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(LookupSymbolGlobalObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static SymbolsKeyInfoSubNode create() {
            return new SymbolsKeyInfoSubNodeGen();
        }

    }
    @GeneratedBy(SymbolsHasKeysSubNode.class)
    static final class SymbolsHasKeysSubNodeGen extends SymbolsHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private SymbolsHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LookupSymbolGlobalObject) */ && arg0Value instanceof LookupSymbolGlobalObject) {
                LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LookupSymbolGlobalObject) {
                    LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LookupSymbolGlobalObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static SymbolsHasKeysSubNode create() {
            return new SymbolsHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(SymbolsReadSubNode.class)
    static final class SymbolsReadSubNodeGen extends SymbolsReadSubNode {

        @CompilationFinal private int state_ = 1;

        private SymbolsReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LookupSymbolGlobalObject, String) */ && arg0Value instanceof LookupSymbolGlobalObject) {
                LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LookupSymbolGlobalObject) {
                    LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(LookupSymbolGlobalObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static SymbolsReadSubNode create() {
            return new SymbolsReadSubNodeGen();
        }

    }
    @GeneratedBy(SymbolsKeysSubNode.class)
    static final class SymbolsKeysSubNodeGen extends SymbolsKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private SymbolsKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LookupSymbolGlobalObject) */ && arg0Value instanceof LookupSymbolGlobalObject) {
                LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LookupSymbolGlobalObject) {
                    LookupSymbolGlobalObject arg0Value_ = (LookupSymbolGlobalObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LookupSymbolGlobalObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static SymbolsKeysSubNode create() {
            return new SymbolsKeysSubNodeGen();
        }

    }
}
