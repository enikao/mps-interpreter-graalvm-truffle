// CheckStyle: start generated
package com.oracle.truffle.api.vm;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.vm.HostLanguage.TopScopeObject;
import com.oracle.truffle.api.vm.TopScopeObjectMessageResolutionForeign.VarsMapHasKeysSubNode;
import com.oracle.truffle.api.vm.TopScopeObjectMessageResolutionForeign.VarsMapInfoSubNode;
import com.oracle.truffle.api.vm.TopScopeObjectMessageResolutionForeign.VarsMapKeysSubNode;
import com.oracle.truffle.api.vm.TopScopeObjectMessageResolutionForeign.VarsMapReadSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(TopScopeObjectMessageResolutionForeign.class)
final class TopScopeObjectMessageResolutionForeignFactory {

    @GeneratedBy(VarsMapInfoSubNode.class)
    static final class VarsMapInfoSubNodeGen extends VarsMapInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TopScopeObject, String) */ && arg0Value instanceof TopScopeObject) {
                TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TopScopeObject) {
                    TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(TopScopeObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapInfoSubNode create() {
            return new VarsMapInfoSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapHasKeysSubNode.class)
    static final class VarsMapHasKeysSubNodeGen extends VarsMapHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TopScopeObject) */ && arg0Value instanceof TopScopeObject) {
                TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TopScopeObject) {
                    TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(TopScopeObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapHasKeysSubNode create() {
            return new VarsMapHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapReadSubNode.class)
    static final class VarsMapReadSubNodeGen extends VarsMapReadSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TopScopeObject, String) */ && arg0Value instanceof TopScopeObject) {
                TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TopScopeObject) {
                    TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(TopScopeObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapReadSubNode create() {
            return new VarsMapReadSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapKeysSubNode.class)
    static final class VarsMapKeysSubNodeGen extends VarsMapKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TopScopeObject) */ && arg0Value instanceof TopScopeObject) {
                TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TopScopeObject) {
                    TopScopeObject arg0Value_ = (TopScopeObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(TopScopeObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapKeysSubNode create() {
            return new VarsMapKeysSubNodeGen();
        }

    }
}
