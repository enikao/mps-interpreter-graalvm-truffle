// CheckStyle: start generated
package com.oracle.truffle.api.vm;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.vm.DefaultScope.VariablesMapObject;
import com.oracle.truffle.api.vm.VariablesMapMessageResolutionForeign.VarsMapHasKeysSubNode;
import com.oracle.truffle.api.vm.VariablesMapMessageResolutionForeign.VarsMapKeyInfoSubNode;
import com.oracle.truffle.api.vm.VariablesMapMessageResolutionForeign.VarsMapKeysSubNode;
import com.oracle.truffle.api.vm.VariablesMapMessageResolutionForeign.VarsMapReadSubNode;
import com.oracle.truffle.api.vm.VariablesMapMessageResolutionForeign.VarsMapWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(VariablesMapMessageResolutionForeign.class)
final class VariablesMapMessageResolutionForeignFactory {

    @GeneratedBy(VarsMapWriteSubNode.class)
    static final class VarsMapWriteSubNodeGen extends VarsMapWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariablesMapObject, String, Object) */ && arg0Value instanceof VariablesMapObject) {
                VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariablesMapObject) {
                    VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(VariablesMapObject, String, Object) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapWriteSubNode create() {
            return new VarsMapWriteSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapKeyInfoSubNode.class)
    static final class VarsMapKeyInfoSubNodeGen extends VarsMapKeyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapKeyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariablesMapObject, String) */ && arg0Value instanceof VariablesMapObject) {
                VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariablesMapObject) {
                    VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(VariablesMapObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapKeyInfoSubNode create() {
            return new VarsMapKeyInfoSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapHasKeysSubNode.class)
    static final class VarsMapHasKeysSubNodeGen extends VarsMapHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariablesMapObject) */ && arg0Value instanceof VariablesMapObject) {
                VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariablesMapObject) {
                    VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(VariablesMapObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapHasKeysSubNode create() {
            return new VarsMapHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapReadSubNode.class)
    static final class VarsMapReadSubNodeGen extends VarsMapReadSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariablesMapObject, String) */ && arg0Value instanceof VariablesMapObject) {
                VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariablesMapObject) {
                    VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(VariablesMapObject, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapReadSubNode create() {
            return new VarsMapReadSubNodeGen();
        }

    }
    @GeneratedBy(VarsMapKeysSubNode.class)
    static final class VarsMapKeysSubNodeGen extends VarsMapKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private VarsMapKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(VariablesMapObject) */ && arg0Value instanceof VariablesMapObject) {
                VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof VariablesMapObject) {
                    VariablesMapObject arg0Value_ = (VariablesMapObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(VariablesMapObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static VarsMapKeysSubNode create() {
            return new VarsMapKeysSubNodeGen();
        }

    }
}
