// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.nfi.ClosureArgumentNode.BufferClosureArgumentNode;
import java.nio.ByteBuffer;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ClosureArgumentNode.class)
final class ClosureArgumentNodeFactory {

    @GeneratedBy(BufferClosureArgumentNode.class)
    static final class BufferClosureArgumentNodeGen extends BufferClosureArgumentNode {

        @CompilationFinal private int state_ = 1;

        private BufferClosureArgumentNodeGen(LibFFIType type) {
            super(type);
        }

        @Override
        public Object execute(Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active deserialize(ByteBuffer) */ && arg0Value instanceof ByteBuffer) {
                ByteBuffer arg0Value_ = (ByteBuffer) arg0Value;
                return deserialize(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ByteBuffer) {
                    ByteBuffer arg0Value_ = (ByteBuffer) arg0Value;
                    this.state_ = state | 0b10 /* add-active deserialize(ByteBuffer) */;
                    lock.unlock();
                    hasLock = false;
                    return deserialize(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static BufferClosureArgumentNode create(LibFFIType type) {
            return new BufferClosureArgumentNodeGen(type);
        }

    }
}
