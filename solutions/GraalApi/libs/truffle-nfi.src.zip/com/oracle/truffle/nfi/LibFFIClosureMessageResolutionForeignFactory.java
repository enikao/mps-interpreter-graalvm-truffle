// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.nfi.LibFFIClosureMessageResolutionForeign.AsNativeClosureSubNode;
import com.oracle.truffle.nfi.LibFFIClosureMessageResolutionForeign.CanResolveLibFFIClosureSubNode;
import com.oracle.truffle.nfi.LibFFIClosureMessageResolutionForeign.IsNativeClosureSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(LibFFIClosureMessageResolutionForeign.class)
final class LibFFIClosureMessageResolutionForeignFactory {

    @GeneratedBy(AsNativeClosureSubNode.class)
    static final class AsNativeClosureSubNodeGen extends AsNativeClosureSubNode {

        @CompilationFinal private int state_ = 1;

        private AsNativeClosureSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIClosure) */ && arg0Value instanceof LibFFIClosure) {
                LibFFIClosure arg0Value_ = (LibFFIClosure) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIClosure) {
                    LibFFIClosure arg0Value_ = (LibFFIClosure) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIClosure) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static AsNativeClosureSubNode create() {
            return new AsNativeClosureSubNodeGen();
        }

    }
    @GeneratedBy(IsNativeClosureSubNode.class)
    static final class IsNativeClosureSubNodeGen extends IsNativeClosureSubNode {

        @CompilationFinal private int state_ = 1;

        private IsNativeClosureSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIClosure) */ && arg0Value instanceof LibFFIClosure) {
                LibFFIClosure arg0Value_ = (LibFFIClosure) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIClosure) {
                    LibFFIClosure arg0Value_ = (LibFFIClosure) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIClosure) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsNativeClosureSubNode create() {
            return new IsNativeClosureSubNodeGen();
        }

    }
    @GeneratedBy(CanResolveLibFFIClosureSubNode.class)
    static final class CanResolveLibFFIClosureSubNodeGen extends CanResolveLibFFIClosureSubNode {

        @CompilationFinal private int state_ = 1;

        private CanResolveLibFFIClosureSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active testWithTarget(TruffleObject) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                return testWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TruffleObject) {
                    TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active testWithTarget(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return testWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static CanResolveLibFFIClosureSubNode create() {
            return new CanResolveLibFFIClosureSubNodeGen();
        }

    }
}
