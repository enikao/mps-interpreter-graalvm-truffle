// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.CanResolveLibFFIFunctionSubNode;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.ExecuteLibFFIFunctionSubNode;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.IsExecutableLibFFIFunctionSubNode;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.LibFFIFunctionKeyInfoSubNode;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.LibFFIFunctionKeysSubNode;
import com.oracle.truffle.nfi.LibFFIFunctionMessageResolutionForeign.ReBindSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(LibFFIFunctionMessageResolutionForeign.class)
final class LibFFIFunctionMessageResolutionForeignFactory {

    @GeneratedBy(ExecuteLibFFIFunctionSubNode.class)
    static final class ExecuteLibFFIFunctionSubNodeGen extends ExecuteLibFFIFunctionSubNode {

        @CompilationFinal private int state_ = 1;

        private ExecuteLibFFIFunctionSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIFunction, Object[]) */ && arg0Value instanceof LibFFIFunction) {
                LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                if (arg1Value instanceof Object[]) {
                    Object[] arg1Value_ = (Object[]) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIFunction) {
                    LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                    if (arg1Value instanceof Object[]) {
                        Object[] arg1Value_ = (Object[]) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIFunction, Object[]) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ExecuteLibFFIFunctionSubNode create() {
            return new ExecuteLibFFIFunctionSubNodeGen();
        }

    }
    @GeneratedBy(ReBindSubNode.class)
    static final class ReBindSubNodeGen extends ReBindSubNode {

        @CompilationFinal private int state_ = 1;

        private ReBindSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIFunction, String, Object[]) */ && arg0Value instanceof LibFFIFunction) {
                LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Object[]) {
                        Object[] arg2Value_ = (Object[]) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIFunction) {
                    LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Object[]) {
                            Object[] arg2Value_ = (Object[]) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIFunction, String, Object[]) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ReBindSubNode create() {
            return new ReBindSubNodeGen();
        }

    }
    @GeneratedBy(LibFFIFunctionKeyInfoSubNode.class)
    static final class LibFFIFunctionKeyInfoSubNodeGen extends LibFFIFunctionKeyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private LibFFIFunctionKeyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIFunction, Object) */ && arg0Value instanceof LibFFIFunction) {
                LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                return accessWithTarget(arg0Value_, arg1Value);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIFunction) {
                    LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIFunction, Object) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_, arg1Value);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static LibFFIFunctionKeyInfoSubNode create() {
            return new LibFFIFunctionKeyInfoSubNodeGen();
        }

    }
    @GeneratedBy(LibFFIFunctionKeysSubNode.class)
    static final class LibFFIFunctionKeysSubNodeGen extends LibFFIFunctionKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private LibFFIFunctionKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIFunction) */ && arg0Value instanceof LibFFIFunction) {
                LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIFunction) {
                    LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIFunction) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static LibFFIFunctionKeysSubNode create() {
            return new LibFFIFunctionKeysSubNodeGen();
        }

    }
    @GeneratedBy(IsExecutableLibFFIFunctionSubNode.class)
    static final class IsExecutableLibFFIFunctionSubNodeGen extends IsExecutableLibFFIFunctionSubNode {

        @CompilationFinal private int state_ = 1;

        private IsExecutableLibFFIFunctionSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(LibFFIFunction) */ && arg0Value instanceof LibFFIFunction) {
                LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof LibFFIFunction) {
                    LibFFIFunction arg0Value_ = (LibFFIFunction) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(LibFFIFunction) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsExecutableLibFFIFunctionSubNode create() {
            return new IsExecutableLibFFIFunctionSubNodeGen();
        }

    }
    @GeneratedBy(CanResolveLibFFIFunctionSubNode.class)
    static final class CanResolveLibFFIFunctionSubNodeGen extends CanResolveLibFFIFunctionSubNode {

        @CompilationFinal private int state_ = 1;

        private CanResolveLibFFIFunctionSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active testWithTarget(TruffleObject) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                return testWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TruffleObject) {
                    TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active testWithTarget(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return testWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static CanResolveLibFFIFunctionSubNode create() {
            return new CanResolveLibFFIFunctionSubNodeGen();
        }

    }
}
