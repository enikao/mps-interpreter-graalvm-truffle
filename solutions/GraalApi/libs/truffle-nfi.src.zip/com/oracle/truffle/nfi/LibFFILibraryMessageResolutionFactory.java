// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import com.oracle.truffle.nfi.LibFFILibraryMessageResolution.CachedLookupSymbolNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(LibFFILibraryMessageResolution.class)
final class LibFFILibraryMessageResolutionFactory {

    @GeneratedBy(CachedLookupSymbolNode.class)
    static final class CachedLookupSymbolNodeGen extends CachedLookupSymbolNode {

        @CompilationFinal private int state_ = 1;
        @CompilationFinal private int exclude_;
        @CompilationFinal private LookupCachedData lookupCached_cache;

        private CachedLookupSymbolNodeGen() {
        }

        @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
        @Override
        protected TruffleObject executeLookup(LibFFILibrary arg0Value, String arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) || lookup(LibFFILibrary, String) */) {
                if ((state & 0b10) != 0 /* is-active lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */) {
                    LookupCachedData s1_ = lookupCached_cache;
                    while (s1_ != null) {
                        if ((arg0Value == s1_.cachedReceiver_) && (arg1Value.equals(s1_.cachedSymbol_))) {
                            return lookupCached(arg0Value, arg1Value, s1_.cachedReceiver_, s1_.cachedSymbol_, s1_.cachedRet_);
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state & 0b100) != 0 /* is-active lookup(LibFFILibrary, String) */) {
                    return lookup(arg0Value, arg1Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private TruffleObject executeAndSpecialize(LibFFILibrary arg0Value, String arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                int exclude = exclude_;
                if ((exclude & 0b1) == 0 /* is-not-excluded lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */) {
                    int count1_ = 0;
                    LookupCachedData s1_ = lookupCached_cache;
                    if ((state & 0b10) != 0 /* is-active lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */) {
                        while (s1_ != null) {
                            if ((arg0Value == s1_.cachedReceiver_) && (arg1Value.equals(s1_.cachedSymbol_))) {
                                break;
                            }
                            s1_ = s1_.next_;
                            count1_++;
                        }
                    }
                    if (s1_ == null) {
                        {
                            LibFFILibrary cachedReceiver = (arg0Value);
                            String cachedSymbol = (arg1Value);
                            // assert (arg0Value == cachedReceiver);
                            // assert (arg1Value.equals(cachedSymbol));
                            if (count1_ < (3)) {
                                TruffleObject cachedRet = (lookup(cachedReceiver, cachedSymbol));
                                s1_ = new LookupCachedData(lookupCached_cache, cachedReceiver, cachedSymbol, cachedRet);
                                this.lookupCached_cache = s1_;
                                this.state_ = state | 0b10 /* add-active lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */;
                            }
                        }
                    }
                    if (s1_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return lookupCached(arg0Value, arg1Value, s1_.cachedReceiver_, s1_.cachedSymbol_, s1_.cachedRet_);
                    }
                }
                this.exclude_ = exclude | 0b1 /* add-excluded lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */;
                this.lookupCached_cache = null;
                state = state & 0xfffffffd /* remove-active lookupCached(LibFFILibrary, String, LibFFILibrary, String, TruffleObject) */;
                this.state_ = state | 0b100 /* add-active lookup(LibFFILibrary, String) */;
                lock.unlock();
                hasLock = false;
                return lookup(arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                LookupCachedData s1_ = this.lookupCached_cache;
                if ((s1_ == null || s1_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        public static CachedLookupSymbolNode create() {
            return new CachedLookupSymbolNodeGen();
        }

        @GeneratedBy(CachedLookupSymbolNode.class)
        private static final class LookupCachedData {

            @CompilationFinal LookupCachedData next_;
            final LibFFILibrary cachedReceiver_;
            final String cachedSymbol_;
            final TruffleObject cachedRet_;

            LookupCachedData(LookupCachedData next_, LibFFILibrary cachedReceiver_, String cachedSymbol_, TruffleObject cachedRet_) {
                this.next_ = next_;
                this.cachedReceiver_ = cachedReceiver_;
                this.cachedSymbol_ = cachedSymbol_;
                this.cachedRet_ = cachedRet_;
            }

        }
    }
}
