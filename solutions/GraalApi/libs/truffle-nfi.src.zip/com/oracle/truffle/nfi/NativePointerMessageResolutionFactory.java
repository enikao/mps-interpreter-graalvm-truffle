// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.nodes.ExplodeLoop;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.api.nodes.ExplodeLoop.LoopExplosionKind;
import com.oracle.truffle.nfi.NativePointerMessageResolution.SignatureCacheNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(NativePointerMessageResolution.class)
final class NativePointerMessageResolutionFactory {

    @GeneratedBy(SignatureCacheNode.class)
    static final class SignatureCacheNodeGen extends SignatureCacheNode {

        @CompilationFinal private int state_ = 1;
        @CompilationFinal private int exclude_;
        @CompilationFinal private CachedData cached_cache;

        private SignatureCacheNodeGen() {
        }

        @ExplodeLoop(kind = LoopExplosionKind.FULL_EXPLODE_UNTIL_RETURN)
        @Override
        protected LibFFISignature execute(String arg0Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active cached(String, String, LibFFISignature) || parse(String) */) {
                if ((state & 0b10) != 0 /* is-active cached(String, String, LibFFISignature) */) {
                    CachedData s1_ = cached_cache;
                    while (s1_ != null) {
                        if ((SignatureCacheNode.checkSignature(arg0Value, s1_.cachedSignature_))) {
                            return cached(arg0Value, s1_.cachedSignature_, s1_.ret_);
                        }
                        s1_ = s1_.next_;
                    }
                }
                if ((state & 0b100) != 0 /* is-active parse(String) */) {
                    return parse(arg0Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private LibFFISignature executeAndSpecialize(String arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                int exclude = exclude_;
                if ((exclude & 0b1) == 0 /* is-not-excluded cached(String, String, LibFFISignature) */) {
                    int count1_ = 0;
                    CachedData s1_ = cached_cache;
                    if ((state & 0b10) != 0 /* is-active cached(String, String, LibFFISignature) */) {
                        while (s1_ != null) {
                            if ((SignatureCacheNode.checkSignature(arg0Value, s1_.cachedSignature_))) {
                                break;
                            }
                            s1_ = s1_.next_;
                            count1_++;
                        }
                    }
                    if (s1_ == null) {
                        {
                            String cachedSignature = (arg0Value);
                            if ((SignatureCacheNode.checkSignature(arg0Value, cachedSignature)) && count1_ < (3)) {
                                LibFFISignature ret = (parse(arg0Value));
                                s1_ = new CachedData(cached_cache, cachedSignature, ret);
                                this.cached_cache = s1_;
                                this.state_ = state | 0b10 /* add-active cached(String, String, LibFFISignature) */;
                            }
                        }
                    }
                    if (s1_ != null) {
                        lock.unlock();
                        hasLock = false;
                        return cached(arg0Value, s1_.cachedSignature_, s1_.ret_);
                    }
                }
                this.exclude_ = exclude | 0b1 /* add-excluded cached(String, String, LibFFISignature) */;
                this.cached_cache = null;
                state = state & 0xfffffffd /* remove-active cached(String, String, LibFFISignature) */;
                this.state_ = state | 0b100 /* add-active parse(String) */;
                lock.unlock();
                hasLock = false;
                return parse(arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                CachedData s1_ = this.cached_cache;
                if ((s1_ == null || s1_.next_ == null)) {
                    return NodeCost.MONOMORPHIC;
                }
            }
            return NodeCost.POLYMORPHIC;
        }

        public static SignatureCacheNode create() {
            return new SignatureCacheNodeGen();
        }

        @GeneratedBy(SignatureCacheNode.class)
        private static final class CachedData {

            @CompilationFinal CachedData next_;
            final String cachedSignature_;
            final LibFFISignature ret_;

            CachedData(CachedData next_, String cachedSignature_, LibFFISignature ret_) {
                this.next_ = next_;
                this.cachedSignature_ = cachedSignature_;
                this.ret_ = ret_;
            }

        }
    }
}
