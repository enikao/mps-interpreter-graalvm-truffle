// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.AsNativePointerSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.BindSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.CanResolveNativePointerSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.IsBoxedNativePointerSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.IsNativePointerSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.IsNullNativePointerSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.NativePointerKeyInfoSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.NativePointerKeysSubNode;
import com.oracle.truffle.nfi.NativePointerMessageResolutionForeign.UnboxNativePointerSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(NativePointerMessageResolutionForeign.class)
final class NativePointerMessageResolutionForeignFactory {

    @GeneratedBy(BindSubNode.class)
    static final class BindSubNodeGen extends BindSubNode {

        @CompilationFinal private int state_ = 1;

        private BindSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer, String, Object[]) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Object[]) {
                        Object[] arg2Value_ = (Object[]) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Object[]) {
                            Object[] arg2Value_ = (Object[]) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer, String, Object[]) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static BindSubNode create() {
            return new BindSubNodeGen();
        }

    }
    @GeneratedBy(NativePointerKeyInfoSubNode.class)
    static final class NativePointerKeyInfoSubNodeGen extends NativePointerKeyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private NativePointerKeyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer, Object) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_, arg1Value);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer, Object) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_, arg1Value);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static NativePointerKeyInfoSubNode create() {
            return new NativePointerKeyInfoSubNodeGen();
        }

    }
    @GeneratedBy(NativePointerKeysSubNode.class)
    static final class NativePointerKeysSubNodeGen extends NativePointerKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private NativePointerKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static NativePointerKeysSubNode create() {
            return new NativePointerKeysSubNodeGen();
        }

    }
    @GeneratedBy(AsNativePointerSubNode.class)
    static final class AsNativePointerSubNodeGen extends AsNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private AsNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static AsNativePointerSubNode create() {
            return new AsNativePointerSubNodeGen();
        }

    }
    @GeneratedBy(IsNullNativePointerSubNode.class)
    static final class IsNullNativePointerSubNodeGen extends IsNullNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private IsNullNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsNullNativePointerSubNode create() {
            return new IsNullNativePointerSubNodeGen();
        }

    }
    @GeneratedBy(UnboxNativePointerSubNode.class)
    static final class UnboxNativePointerSubNodeGen extends UnboxNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private UnboxNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static UnboxNativePointerSubNode create() {
            return new UnboxNativePointerSubNodeGen();
        }

    }
    @GeneratedBy(IsBoxedNativePointerSubNode.class)
    static final class IsBoxedNativePointerSubNodeGen extends IsBoxedNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private IsBoxedNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsBoxedNativePointerSubNode create() {
            return new IsBoxedNativePointerSubNodeGen();
        }

    }
    @GeneratedBy(IsNativePointerSubNode.class)
    static final class IsNativePointerSubNodeGen extends IsNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private IsNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativePointer) */ && arg0Value instanceof NativePointer) {
                NativePointer arg0Value_ = (NativePointer) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativePointer) {
                    NativePointer arg0Value_ = (NativePointer) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativePointer) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsNativePointerSubNode create() {
            return new IsNativePointerSubNodeGen();
        }

    }
    @GeneratedBy(CanResolveNativePointerSubNode.class)
    static final class CanResolveNativePointerSubNodeGen extends CanResolveNativePointerSubNode {

        @CompilationFinal private int state_ = 1;

        private CanResolveNativePointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active testWithTarget(TruffleObject) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                return testWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TruffleObject) {
                    TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active testWithTarget(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return testWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static CanResolveNativePointerSubNode create() {
            return new CanResolveNativePointerSubNodeGen();
        }

    }
}
