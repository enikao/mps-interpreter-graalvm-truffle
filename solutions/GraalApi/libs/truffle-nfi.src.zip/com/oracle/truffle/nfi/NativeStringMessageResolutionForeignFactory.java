// CheckStyle: start generated
package com.oracle.truffle.nfi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.AsPointerNativeStringSubNode;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.CanResolveNativeStringSubNode;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.IsBoxedNativeStringSubNode;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.IsNullNativeStringSubNode;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.IsPointerNativeStringSubNode;
import com.oracle.truffle.nfi.NativeStringMessageResolutionForeign.UnboxNativeStringSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(NativeStringMessageResolutionForeign.class)
final class NativeStringMessageResolutionForeignFactory {

    @GeneratedBy(AsPointerNativeStringSubNode.class)
    static final class AsPointerNativeStringSubNodeGen extends AsPointerNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private AsPointerNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativeString) */ && arg0Value instanceof NativeString) {
                NativeString arg0Value_ = (NativeString) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativeString) {
                    NativeString arg0Value_ = (NativeString) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativeString) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static AsPointerNativeStringSubNode create() {
            return new AsPointerNativeStringSubNodeGen();
        }

    }
    @GeneratedBy(IsNullNativeStringSubNode.class)
    static final class IsNullNativeStringSubNodeGen extends IsNullNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private IsNullNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativeString) */ && arg0Value instanceof NativeString) {
                NativeString arg0Value_ = (NativeString) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativeString) {
                    NativeString arg0Value_ = (NativeString) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativeString) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsNullNativeStringSubNode create() {
            return new IsNullNativeStringSubNodeGen();
        }

    }
    @GeneratedBy(UnboxNativeStringSubNode.class)
    static final class UnboxNativeStringSubNodeGen extends UnboxNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private UnboxNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativeString) */ && arg0Value instanceof NativeString) {
                NativeString arg0Value_ = (NativeString) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativeString) {
                    NativeString arg0Value_ = (NativeString) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativeString) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static UnboxNativeStringSubNode create() {
            return new UnboxNativeStringSubNodeGen();
        }

    }
    @GeneratedBy(IsBoxedNativeStringSubNode.class)
    static final class IsBoxedNativeStringSubNodeGen extends IsBoxedNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private IsBoxedNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativeString) */ && arg0Value instanceof NativeString) {
                NativeString arg0Value_ = (NativeString) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativeString) {
                    NativeString arg0Value_ = (NativeString) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativeString) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsBoxedNativeStringSubNode create() {
            return new IsBoxedNativeStringSubNodeGen();
        }

    }
    @GeneratedBy(IsPointerNativeStringSubNode.class)
    static final class IsPointerNativeStringSubNodeGen extends IsPointerNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private IsPointerNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(NativeString) */ && arg0Value instanceof NativeString) {
                NativeString arg0Value_ = (NativeString) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof NativeString) {
                    NativeString arg0Value_ = (NativeString) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(NativeString) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static IsPointerNativeStringSubNode create() {
            return new IsPointerNativeStringSubNodeGen();
        }

    }
    @GeneratedBy(CanResolveNativeStringSubNode.class)
    static final class CanResolveNativeStringSubNodeGen extends CanResolveNativeStringSubNode {

        @CompilationFinal private int state_ = 1;

        private CanResolveNativeStringSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active testWithTarget(TruffleObject) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                return testWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TruffleObject) {
                    TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active testWithTarget(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return testWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static CanResolveNativeStringSubNode create() {
            return new CanResolveNativeStringSubNodeGen();
        }

    }
}
