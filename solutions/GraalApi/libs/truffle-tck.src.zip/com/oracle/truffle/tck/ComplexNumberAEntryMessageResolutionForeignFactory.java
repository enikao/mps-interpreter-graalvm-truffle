// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.ComplexNumberAEntryMessageResolutionForeign.ComplexNumbersAEntryHasKeysSubNode;
import com.oracle.truffle.tck.ComplexNumberAEntryMessageResolutionForeign.ComplexNumbersAEntryKeysSubNode;
import com.oracle.truffle.tck.ComplexNumberAEntryMessageResolutionForeign.ComplexNumbersAEntryReadSubNode;
import com.oracle.truffle.tck.ComplexNumberAEntryMessageResolutionForeign.ComplexNumbersAEntryWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ComplexNumberAEntryMessageResolutionForeign.class)
final class ComplexNumberAEntryMessageResolutionForeignFactory {

    @GeneratedBy(ComplexNumbersAEntryWriteSubNode.class)
    static final class ComplexNumbersAEntryWriteSubNodeGen extends ComplexNumbersAEntryWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAEntryWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberAEntry, String, Number) */ && arg0Value instanceof ComplexNumberAEntry) {
                ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Number) {
                        Number arg2Value_ = (Number) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberAEntry) {
                    ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Number) {
                            Number arg2Value_ = (Number) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberAEntry, String, Number) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAEntryWriteSubNode create() {
            return new ComplexNumbersAEntryWriteSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAEntryHasKeysSubNode.class)
    static final class ComplexNumbersAEntryHasKeysSubNodeGen extends ComplexNumbersAEntryHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAEntryHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberAEntry) */ && arg0Value instanceof ComplexNumberAEntry) {
                ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberAEntry) {
                    ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberAEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAEntryHasKeysSubNode create() {
            return new ComplexNumbersAEntryHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAEntryReadSubNode.class)
    static final class ComplexNumbersAEntryReadSubNodeGen extends ComplexNumbersAEntryReadSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAEntryReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberAEntry, String) */ && arg0Value instanceof ComplexNumberAEntry) {
                ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberAEntry) {
                    ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberAEntry, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAEntryReadSubNode create() {
            return new ComplexNumbersAEntryReadSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAEntryKeysSubNode.class)
    static final class ComplexNumbersAEntryKeysSubNodeGen extends ComplexNumbersAEntryKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAEntryKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberAEntry) */ && arg0Value instanceof ComplexNumberAEntry) {
                ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberAEntry) {
                    ComplexNumberAEntry arg0Value_ = (ComplexNumberAEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberAEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAEntryKeysSubNode create() {
            return new ComplexNumbersAEntryKeysSubNodeGen();
        }

    }
}
