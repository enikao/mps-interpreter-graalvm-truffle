// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.ComplexNumberBEntryMessageResolutionForeign.ComplexNumbersBEntryHasKeysSubNode;
import com.oracle.truffle.tck.ComplexNumberBEntryMessageResolutionForeign.ComplexNumbersBEntryKeysSubNode;
import com.oracle.truffle.tck.ComplexNumberBEntryMessageResolutionForeign.ComplexNumbersBEntryReadSubNode;
import com.oracle.truffle.tck.ComplexNumberBEntryMessageResolutionForeign.ComplexNumbersBEntryWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ComplexNumberBEntryMessageResolutionForeign.class)
final class ComplexNumberBEntryMessageResolutionForeignFactory {

    @GeneratedBy(ComplexNumbersBEntryWriteSubNode.class)
    static final class ComplexNumbersBEntryWriteSubNodeGen extends ComplexNumbersBEntryWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersBEntryWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberBEntry, String, Number) */ && arg0Value instanceof ComplexNumberBEntry) {
                ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Number) {
                        Number arg2Value_ = (Number) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberBEntry) {
                    ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Number) {
                            Number arg2Value_ = (Number) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberBEntry, String, Number) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersBEntryWriteSubNode create() {
            return new ComplexNumbersBEntryWriteSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersBEntryHasKeysSubNode.class)
    static final class ComplexNumbersBEntryHasKeysSubNodeGen extends ComplexNumbersBEntryHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersBEntryHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberBEntry) */ && arg0Value instanceof ComplexNumberBEntry) {
                ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberBEntry) {
                    ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberBEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersBEntryHasKeysSubNode create() {
            return new ComplexNumbersBEntryHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersBEntryReadSubNode.class)
    static final class ComplexNumbersBEntryReadSubNodeGen extends ComplexNumbersBEntryReadSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersBEntryReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberBEntry, String) */ && arg0Value instanceof ComplexNumberBEntry) {
                ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberBEntry) {
                    ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberBEntry, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersBEntryReadSubNode create() {
            return new ComplexNumbersBEntryReadSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersBEntryKeysSubNode.class)
    static final class ComplexNumbersBEntryKeysSubNodeGen extends ComplexNumbersBEntryKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersBEntryKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumberBEntry) */ && arg0Value instanceof ComplexNumberBEntry) {
                ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumberBEntry) {
                    ComplexNumberBEntry arg0Value_ = (ComplexNumberBEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumberBEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersBEntryKeysSubNode create() {
            return new ComplexNumbersBEntryKeysSubNodeGen();
        }

    }
}
