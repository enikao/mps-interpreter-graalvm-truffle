// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexGetSizeSubNode;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexHasSizeSubNode;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexInvokeSubNode;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexIsNullSubNode;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexReadSubNode;
import com.oracle.truffle.tck.ComplexNumberMessageResolutionForeign.ComplexWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ComplexNumberMessageResolutionForeign.class)
final class ComplexNumberMessageResolutionForeignFactory {

    @GeneratedBy(ComplexWriteSubNode.class)
    static final class ComplexWriteSubNodeGen extends ComplexWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(ComplexNumber, String, Number) || accessWithTarget(ComplexNumber, int, Number) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                if (arg2Value instanceof Number) {
                    Number arg2Value_ = (Number) arg2Value;
                    if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber, String, Number) */ && arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                    if ((state & 0b100) != 0 /* is-active accessWithTarget(ComplexNumber, int, Number) */ && arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    if (arg2Value instanceof Number) {
                        Number arg2Value_ = (Number) arg2Value;
                        if (arg1Value instanceof String) {
                            String arg1Value_ = (String) arg1Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber, String, Number) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                        if (arg1Value instanceof Integer) {
                            int arg1Value_ = (int) arg1Value;
                            this.state_ = state | 0b100 /* add-active accessWithTarget(ComplexNumber, int, Number) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static ComplexWriteSubNode create() {
            return new ComplexWriteSubNodeGen();
        }

    }
    @GeneratedBy(ComplexInvokeSubNode.class)
    static final class ComplexInvokeSubNodeGen extends ComplexInvokeSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexInvokeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber, String, Object[]) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    if (arg2Value instanceof Object[]) {
                        Object[] arg2Value_ = (Object[]) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        if (arg2Value instanceof Object[]) {
                            Object[] arg2Value_ = (Object[]) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber, String, Object[]) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexInvokeSubNode create() {
            return new ComplexInvokeSubNodeGen();
        }

    }
    @GeneratedBy(ComplexReadSubNode.class)
    static final class ComplexReadSubNodeGen extends ComplexReadSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(ComplexNumber, String) || accessWithTarget(ComplexNumber, int) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber, String) */ && arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(ComplexNumber, int) */ && arg1Value instanceof Integer) {
                    int arg1Value_ = (int) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                    if (arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(ComplexNumber, int) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static ComplexReadSubNode create() {
            return new ComplexReadSubNodeGen();
        }

    }
    @GeneratedBy(ComplexIsNullSubNode.class)
    static final class ComplexIsNullSubNodeGen extends ComplexIsNullSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexIsNullSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexIsNullSubNode create() {
            return new ComplexIsNullSubNodeGen();
        }

    }
    @GeneratedBy(ComplexGetSizeSubNode.class)
    static final class ComplexGetSizeSubNodeGen extends ComplexGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexGetSizeSubNode create() {
            return new ComplexGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(ComplexHasSizeSubNode.class)
    static final class ComplexHasSizeSubNodeGen extends ComplexHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumber) */ && arg0Value instanceof ComplexNumber) {
                ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumber) {
                    ComplexNumber arg0Value_ = (ComplexNumber) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumber) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexHasSizeSubNode create() {
            return new ComplexHasSizeSubNodeGen();
        }

    }
}
