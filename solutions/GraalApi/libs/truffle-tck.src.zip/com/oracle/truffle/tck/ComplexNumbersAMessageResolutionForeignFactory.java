// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.ComplexNumbersAMessageResolutionForeign.ComplexNumbersAGetSizeSubNode;
import com.oracle.truffle.tck.ComplexNumbersAMessageResolutionForeign.ComplexNumbersAHasSizeSubNode;
import com.oracle.truffle.tck.ComplexNumbersAMessageResolutionForeign.ComplexNumbersAReadSubNode;
import com.oracle.truffle.tck.ComplexNumbersAMessageResolutionForeign.ComplexNumbersAWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ComplexNumbersAMessageResolutionForeign.class)
final class ComplexNumbersAMessageResolutionForeignFactory {

    @GeneratedBy(ComplexNumbersAWriteSubNode.class)
    static final class ComplexNumbersAWriteSubNodeGen extends ComplexNumbersAWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumbersA, Number, TruffleObject) */ && arg0Value instanceof ComplexNumbersA) {
                ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                if (arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    if (arg2Value instanceof TruffleObject) {
                        TruffleObject arg2Value_ = (TruffleObject) arg2Value;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumbersA) {
                    ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        if (arg2Value instanceof TruffleObject) {
                            TruffleObject arg2Value_ = (TruffleObject) arg2Value;
                            this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumbersA, Number, TruffleObject) */;
                            lock.unlock();
                            hasLock = false;
                            return accessWithTarget(arg0Value_, arg1Value_, arg2Value_);
                        }
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAWriteSubNode create() {
            return new ComplexNumbersAWriteSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAReadSubNode.class)
    static final class ComplexNumbersAReadSubNodeGen extends ComplexNumbersAReadSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumbersA, Number) */ && arg0Value instanceof ComplexNumbersA) {
                ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                if (arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumbersA) {
                    ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumbersA, Number) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAReadSubNode create() {
            return new ComplexNumbersAReadSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAGetSizeSubNode.class)
    static final class ComplexNumbersAGetSizeSubNodeGen extends ComplexNumbersAGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumbersA) */ && arg0Value instanceof ComplexNumbersA) {
                ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumbersA) {
                    ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumbersA) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAGetSizeSubNode create() {
            return new ComplexNumbersAGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(ComplexNumbersAHasSizeSubNode.class)
    static final class ComplexNumbersAHasSizeSubNodeGen extends ComplexNumbersAHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ComplexNumbersAHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ComplexNumbersA) */ && arg0Value instanceof ComplexNumbersA) {
                ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ComplexNumbersA) {
                    ComplexNumbersA arg0Value_ = (ComplexNumbersA) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ComplexNumbersA) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ComplexNumbersAHasSizeSubNode create() {
            return new ComplexNumbersAHasSizeSubNodeGen();
        }

    }
}
