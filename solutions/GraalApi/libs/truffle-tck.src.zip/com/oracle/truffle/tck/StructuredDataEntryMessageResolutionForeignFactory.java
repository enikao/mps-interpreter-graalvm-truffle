// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.StructuredDataEntryMessageResolutionForeign.StructuredDataEntryHasKeysSubNode;
import com.oracle.truffle.tck.StructuredDataEntryMessageResolutionForeign.StructuredDataEntryKeyInfoSubNode;
import com.oracle.truffle.tck.StructuredDataEntryMessageResolutionForeign.StructuredDataEntryKeysSubNode;
import com.oracle.truffle.tck.StructuredDataEntryMessageResolutionForeign.StructuredDataEntryReadSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(StructuredDataEntryMessageResolutionForeign.class)
final class StructuredDataEntryMessageResolutionForeignFactory {

    @GeneratedBy(StructuredDataEntryKeyInfoSubNode.class)
    static final class StructuredDataEntryKeyInfoSubNodeGen extends StructuredDataEntryKeyInfoSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataEntryKeyInfoSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredDataEntry, Object) */ && arg0Value instanceof StructuredDataEntry) {
                StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                return accessWithTarget(arg0Value_, arg1Value);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredDataEntry) {
                    StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredDataEntry, Object) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_, arg1Value);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataEntryKeyInfoSubNode create() {
            return new StructuredDataEntryKeyInfoSubNodeGen();
        }

    }
    @GeneratedBy(StructuredDataEntryHasKeysSubNode.class)
    static final class StructuredDataEntryHasKeysSubNodeGen extends StructuredDataEntryHasKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataEntryHasKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredDataEntry) */ && arg0Value instanceof StructuredDataEntry) {
                StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredDataEntry) {
                    StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredDataEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataEntryHasKeysSubNode create() {
            return new StructuredDataEntryHasKeysSubNodeGen();
        }

    }
    @GeneratedBy(StructuredDataEntryReadSubNode.class)
    static final class StructuredDataEntryReadSubNodeGen extends StructuredDataEntryReadSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataEntryReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredDataEntry, String) */ && arg0Value instanceof StructuredDataEntry) {
                StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                if (arg1Value instanceof String) {
                    String arg1Value_ = (String) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredDataEntry) {
                    StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                    if (arg1Value instanceof String) {
                        String arg1Value_ = (String) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredDataEntry, String) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataEntryReadSubNode create() {
            return new StructuredDataEntryReadSubNodeGen();
        }

    }
    @GeneratedBy(StructuredDataEntryKeysSubNode.class)
    static final class StructuredDataEntryKeysSubNodeGen extends StructuredDataEntryKeysSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataEntryKeysSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredDataEntry) */ && arg0Value instanceof StructuredDataEntry) {
                StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredDataEntry) {
                    StructuredDataEntry arg0Value_ = (StructuredDataEntry) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredDataEntry) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataEntryKeysSubNode create() {
            return new StructuredDataEntryKeysSubNodeGen();
        }

    }
}
