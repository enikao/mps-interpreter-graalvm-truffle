// CheckStyle: start generated
package com.oracle.truffle.tck;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.tck.StructuredDataMessageResolutionForeign.StructuredDataGetSizeSubNode;
import com.oracle.truffle.tck.StructuredDataMessageResolutionForeign.StructuredDataHasSizeSubNode;
import com.oracle.truffle.tck.StructuredDataMessageResolutionForeign.StructuredDataReadSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(StructuredDataMessageResolutionForeign.class)
final class StructuredDataMessageResolutionForeignFactory {

    @GeneratedBy(StructuredDataReadSubNode.class)
    static final class StructuredDataReadSubNodeGen extends StructuredDataReadSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredData, Number) */ && arg0Value instanceof StructuredData) {
                StructuredData arg0Value_ = (StructuredData) arg0Value;
                if (arg1Value instanceof Number) {
                    Number arg1Value_ = (Number) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredData) {
                    StructuredData arg0Value_ = (StructuredData) arg0Value;
                    if (arg1Value instanceof Number) {
                        Number arg1Value_ = (Number) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredData, Number) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataReadSubNode create() {
            return new StructuredDataReadSubNodeGen();
        }

    }
    @GeneratedBy(StructuredDataGetSizeSubNode.class)
    static final class StructuredDataGetSizeSubNodeGen extends StructuredDataGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredData) */ && arg0Value instanceof StructuredData) {
                StructuredData arg0Value_ = (StructuredData) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredData) {
                    StructuredData arg0Value_ = (StructuredData) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredData) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataGetSizeSubNode create() {
            return new StructuredDataGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(StructuredDataHasSizeSubNode.class)
    static final class StructuredDataHasSizeSubNodeGen extends StructuredDataHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private StructuredDataHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(StructuredData) */ && arg0Value instanceof StructuredData) {
                StructuredData arg0Value_ = (StructuredData) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof StructuredData) {
                    StructuredData arg0Value_ = (StructuredData) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(StructuredData) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static StructuredDataHasSizeSubNode create() {
            return new StructuredDataHasSizeSubNodeGen();
        }

    }
}
