// CheckStyle: start generated
package com.oracle.truffle.tck.impl;

import java.util.Arrays;
import java.util.Iterator;
import org.graalvm.options.OptionCategory;
import org.graalvm.options.OptionDescriptor;
import org.graalvm.options.OptionDescriptors;

final class DebugALotOptionDescriptors implements OptionDescriptors {

    @Override
    public OptionDescriptor get(String optionName) {
        switch (optionName) {
            case "debugalot" :
                return OptionDescriptor.newBuilder(DebugALot.DebugALot, "debugalot").deprecated(false).help("Start debugging logger.").category(OptionCategory.EXPERT).build();
            case "debugalot.Eval" :
                return OptionDescriptor.newBuilder(DebugALot.Eval, "debugalot.Eval").deprecated(false).help("Whether to test evaluations. (default:false)").category(OptionCategory.EXPERT).build();
            case "debugalot.FailFast" :
                return OptionDescriptor.newBuilder(DebugALot.FailFast, "debugalot.FailFast").deprecated(false).help("Fail fast, give up after the first error. (default:false)").category(OptionCategory.EXPERT).build();
            case "debugalot.LogFile" :
                return OptionDescriptor.newBuilder(DebugALot.LogFile, "debugalot.LogFile").deprecated(false).help("File to print the debugger log into. (default:standard output)").category(OptionCategory.EXPERT).build();
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return Arrays.asList(
            OptionDescriptor.newBuilder(DebugALot.DebugALot, "debugalot").deprecated(false).help("Start debugging logger.").category(OptionCategory.EXPERT).build(),
            OptionDescriptor.newBuilder(DebugALot.Eval, "debugalot.Eval").deprecated(false).help("Whether to test evaluations. (default:false)").category(OptionCategory.EXPERT).build(),
            OptionDescriptor.newBuilder(DebugALot.FailFast, "debugalot.FailFast").deprecated(false).help("Fail fast, give up after the first error. (default:false)").category(OptionCategory.EXPERT).build(),
            OptionDescriptor.newBuilder(DebugALot.LogFile, "debugalot.LogFile").deprecated(false).help("File to print the debugger log into. (default:standard output)").category(OptionCategory.EXPERT).build())
        .iterator();
    }

}
