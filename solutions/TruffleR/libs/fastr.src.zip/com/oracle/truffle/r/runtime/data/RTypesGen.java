// CheckStyle: start generated
package com.oracle.truffle.r.runtime.data;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.nodes.UnexpectedResultException;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropByte;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropChar;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropFloat;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropLong;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropShort;
import com.oracle.truffle.r.runtime.data.model.RAbstractAtomicVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractComplexVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractContainer;
import com.oracle.truffle.r.runtime.data.model.RAbstractDoubleVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractIntVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractListVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractLogicalVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractRawVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractStringVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractVector;
import com.oracle.truffle.r.runtime.env.REnvironment;

@GeneratedBy(RTypes.class)
public final class RTypesGen extends RTypes {

    @Deprecated public static final RTypesGen RTYPES = new RTypesGen();

    protected RTypesGen() {
    }

    public static boolean isByte(Object value) {
        return value instanceof Byte;
    }

    public static byte asByte(Object value) {
        assert value instanceof Byte : "RTypesGen.asByte: byte expected";
        return (byte) value;
    }

    public static byte expectByte(Object value) throws UnexpectedResultException {
        if (value instanceof Byte) {
            return (byte) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractLogicalVector(Object value) {
        return value instanceof RAbstractLogicalVector;
    }

    public static RAbstractLogicalVector asRAbstractLogicalVector(Object value) {
        assert value instanceof RAbstractLogicalVector : "RTypesGen.asRAbstractLogicalVector: RAbstractLogicalVector expected";
        return (RAbstractLogicalVector) value;
    }

    public static RAbstractLogicalVector expectRAbstractLogicalVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractLogicalVector) {
            return (RAbstractLogicalVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRInteropByte(Object value) {
        return value instanceof RInteropByte;
    }

    public static RInteropByte asRInteropByte(Object value) {
        assert value instanceof RInteropByte : "RTypesGen.asRInteropByte: RInteropByte expected";
        return (RInteropByte) value;
    }

    public static RInteropByte expectRInteropByte(Object value) throws UnexpectedResultException {
        if (value instanceof RInteropByte) {
            return (RInteropByte) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRInteropChar(Object value) {
        return value instanceof RInteropChar;
    }

    public static RInteropChar asRInteropChar(Object value) {
        assert value instanceof RInteropChar : "RTypesGen.asRInteropChar: RInteropChar expected";
        return (RInteropChar) value;
    }

    public static RInteropChar expectRInteropChar(Object value) throws UnexpectedResultException {
        if (value instanceof RInteropChar) {
            return (RInteropChar) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRInteropFloat(Object value) {
        return value instanceof RInteropFloat;
    }

    public static RInteropFloat asRInteropFloat(Object value) {
        assert value instanceof RInteropFloat : "RTypesGen.asRInteropFloat: RInteropFloat expected";
        return (RInteropFloat) value;
    }

    public static RInteropFloat expectRInteropFloat(Object value) throws UnexpectedResultException {
        if (value instanceof RInteropFloat) {
            return (RInteropFloat) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRInteropLong(Object value) {
        return value instanceof RInteropLong;
    }

    public static RInteropLong asRInteropLong(Object value) {
        assert value instanceof RInteropLong : "RTypesGen.asRInteropLong: RInteropLong expected";
        return (RInteropLong) value;
    }

    public static RInteropLong expectRInteropLong(Object value) throws UnexpectedResultException {
        if (value instanceof RInteropLong) {
            return (RInteropLong) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRInteropShort(Object value) {
        return value instanceof RInteropShort;
    }

    public static RInteropShort asRInteropShort(Object value) {
        assert value instanceof RInteropShort : "RTypesGen.asRInteropShort: RInteropShort expected";
        return (RInteropShort) value;
    }

    public static RInteropShort expectRInteropShort(Object value) throws UnexpectedResultException {
        if (value instanceof RInteropShort) {
            return (RInteropShort) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isInteger(Object value) {
        return value instanceof Integer;
    }

    public static int asInteger(Object value) {
        assert value instanceof Integer : "RTypesGen.asInteger: int expected";
        return (int) value;
    }

    public static int expectInteger(Object value) throws UnexpectedResultException {
        if (value instanceof Integer) {
            return (int) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractIntVector(Object value) {
        return value instanceof RAbstractIntVector;
    }

    public static RAbstractIntVector asRAbstractIntVector(Object value) {
        assert value instanceof RAbstractIntVector : "RTypesGen.asRAbstractIntVector: RAbstractIntVector expected";
        return (RAbstractIntVector) value;
    }

    public static RAbstractIntVector expectRAbstractIntVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractIntVector) {
            return (RAbstractIntVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isDouble(Object value) {
        return value instanceof Double;
    }

    public static double asDouble(Object value) {
        assert value instanceof Double : "RTypesGen.asDouble: double expected";
        return (double) value;
    }

    public static double expectDouble(Object value) throws UnexpectedResultException {
        if (value instanceof Double) {
            return (double) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractDoubleVector(Object value) {
        return value instanceof RAbstractDoubleVector;
    }

    public static RAbstractDoubleVector asRAbstractDoubleVector(Object value) {
        assert value instanceof RAbstractDoubleVector : "RTypesGen.asRAbstractDoubleVector: RAbstractDoubleVector expected";
        return (RAbstractDoubleVector) value;
    }

    public static RAbstractDoubleVector expectRAbstractDoubleVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractDoubleVector) {
            return (RAbstractDoubleVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isString(Object value) {
        return value instanceof String;
    }

    public static String asString(Object value) {
        assert value instanceof String : "RTypesGen.asString: String expected";
        return (String) value;
    }

    public static String expectString(Object value) throws UnexpectedResultException {
        if (value instanceof String) {
            return (String) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractStringVector(Object value) {
        return value instanceof RAbstractStringVector;
    }

    public static RAbstractStringVector asRAbstractStringVector(Object value) {
        assert value instanceof RAbstractStringVector : "RTypesGen.asRAbstractStringVector: RAbstractStringVector expected";
        return (RAbstractStringVector) value;
    }

    public static RAbstractStringVector expectRAbstractStringVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractStringVector) {
            return (RAbstractStringVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRRaw(Object value) {
        return value instanceof RRaw;
    }

    public static RRaw asRRaw(Object value) {
        assert value instanceof RRaw : "RTypesGen.asRRaw: RRaw expected";
        return (RRaw) value;
    }

    public static RRaw expectRRaw(Object value) throws UnexpectedResultException {
        if (value instanceof RRaw) {
            return (RRaw) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractRawVector(Object value) {
        return value instanceof RAbstractRawVector;
    }

    public static RAbstractRawVector asRAbstractRawVector(Object value) {
        assert value instanceof RAbstractRawVector : "RTypesGen.asRAbstractRawVector: RAbstractRawVector expected";
        return (RAbstractRawVector) value;
    }

    public static RAbstractRawVector expectRAbstractRawVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractRawVector) {
            return (RAbstractRawVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRComplex(Object value) {
        return value instanceof RComplex;
    }

    public static RComplex asRComplex(Object value) {
        assert value instanceof RComplex : "RTypesGen.asRComplex: RComplex expected";
        return (RComplex) value;
    }

    public static RComplex expectRComplex(Object value) throws UnexpectedResultException {
        if (value instanceof RComplex) {
            return (RComplex) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractComplexVector(Object value) {
        return value instanceof RAbstractComplexVector;
    }

    public static RAbstractComplexVector asRAbstractComplexVector(Object value) {
        assert value instanceof RAbstractComplexVector : "RTypesGen.asRAbstractComplexVector: RAbstractComplexVector expected";
        return (RAbstractComplexVector) value;
    }

    public static RAbstractComplexVector expectRAbstractComplexVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractComplexVector) {
            return (RAbstractComplexVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractListVector(Object value) {
        return value instanceof RAbstractListVector;
    }

    public static RAbstractListVector asRAbstractListVector(Object value) {
        assert value instanceof RAbstractListVector : "RTypesGen.asRAbstractListVector: RAbstractListVector expected";
        return (RAbstractListVector) value;
    }

    public static RAbstractListVector expectRAbstractListVector(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractListVector) {
            return (RAbstractListVector) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static RNull expectRNull(Object value) throws UnexpectedResultException {
        if (RTypes.isRNull(value)) {
            return RTypes.asRNull(value);
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRExpression(Object value) {
        return value instanceof RExpression;
    }

    public static RExpression asRExpression(Object value) {
        assert value instanceof RExpression : "RTypesGen.asRExpression: RExpression expected";
        return (RExpression) value;
    }

    public static RExpression expectRExpression(Object value) throws UnexpectedResultException {
        if (value instanceof RExpression) {
            return (RExpression) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRPromise(Object value) {
        return value instanceof RPromise;
    }

    public static RPromise asRPromise(Object value) {
        assert value instanceof RPromise : "RTypesGen.asRPromise: RPromise expected";
        return (RPromise) value;
    }

    public static RPromise expectRPromise(Object value) throws UnexpectedResultException {
        if (value instanceof RPromise) {
            return (RPromise) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static RMissing expectRMissing(Object value) throws UnexpectedResultException {
        if (RTypes.isRMissing(value)) {
            return RTypes.asRMissing(value);
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRPairList(Object value) {
        return value instanceof RPairList;
    }

    public static RPairList asRPairList(Object value) {
        assert value instanceof RPairList : "RTypesGen.asRPairList: RPairList expected";
        return (RPairList) value;
    }

    public static RPairList expectRPairList(Object value) throws UnexpectedResultException {
        if (value instanceof RPairList) {
            return (RPairList) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRSymbol(Object value) {
        return value instanceof RSymbol;
    }

    public static RSymbol asRSymbol(Object value) {
        assert value instanceof RSymbol : "RTypesGen.asRSymbol: RSymbol expected";
        return (RSymbol) value;
    }

    public static RSymbol expectRSymbol(Object value) throws UnexpectedResultException {
        if (value instanceof RSymbol) {
            return (RSymbol) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRLanguage(Object value) {
        return value instanceof RLanguage;
    }

    public static RLanguage asRLanguage(Object value) {
        assert value instanceof RLanguage : "RTypesGen.asRLanguage: RLanguage expected";
        return (RLanguage) value;
    }

    public static RLanguage expectRLanguage(Object value) throws UnexpectedResultException {
        if (value instanceof RLanguage) {
            return (RLanguage) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRFunction(Object value) {
        return value instanceof RFunction;
    }

    public static RFunction asRFunction(Object value) {
        assert value instanceof RFunction : "RTypesGen.asRFunction: RFunction expected";
        return (RFunction) value;
    }

    public static RFunction expectRFunction(Object value) throws UnexpectedResultException {
        if (value instanceof RFunction) {
            return (RFunction) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isREnvironment(Object value) {
        return value instanceof REnvironment;
    }

    public static REnvironment asREnvironment(Object value) {
        assert value instanceof REnvironment : "RTypesGen.asREnvironment: REnvironment expected";
        return (REnvironment) value;
    }

    public static REnvironment expectREnvironment(Object value) throws UnexpectedResultException {
        if (value instanceof REnvironment) {
            return (REnvironment) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRAbstractContainer(Object value) {
        return value instanceof RAbstractContainer;
    }

    public static RAbstractContainer asRAbstractContainer(Object value) {
        assert value instanceof RAbstractContainer : "RTypesGen.asRAbstractContainer: RAbstractContainer expected";
        return (RAbstractContainer) value;
    }

    public static RAbstractContainer expectRAbstractContainer(Object value) throws UnexpectedResultException {
        if (value instanceof RAbstractContainer) {
            return (RAbstractContainer) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static boolean isRArgsValuesAndNames(Object value) {
        return value instanceof RArgsValuesAndNames;
    }

    public static RArgsValuesAndNames asRArgsValuesAndNames(Object value) {
        assert value instanceof RArgsValuesAndNames : "RTypesGen.asRArgsValuesAndNames: RArgsValuesAndNames expected";
        return (RArgsValuesAndNames) value;
    }

    public static RArgsValuesAndNames expectRArgsValuesAndNames(Object value) throws UnexpectedResultException {
        if (value instanceof RArgsValuesAndNames) {
            return (RArgsValuesAndNames) value;
        }
        throw new UnexpectedResultException(value);
    }

    public static RMissing expectImplicitRMissing(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && RTypes.isRMissing(value)) {
            return RTypes.asRMissing(value);
        } else if ((state & 0b10) != 0 && value instanceof REmpty) {
            return toRMissing((REmpty) value);
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRMissing(int state, Object value) {
        return ((state & 0b1) != 0 && RTypes.isRMissing(value))
             || ((state & 0b10) != 0 && value instanceof REmpty);
    }

    public static RMissing asImplicitRMissing(int state, Object value) {
        if ((state & 0b1) != 0 && RTypes.isRMissing(value)) {
            return RTypes.asRMissing(value);
        } else if ((state & 0b10) != 0 && value instanceof REmpty) {
            return toRMissing((REmpty) value);
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRMissing(Object value) {
        if (RTypes.isRMissing(value)) {
            return 0b1;
        } else if (value instanceof REmpty) {
            return 0b10;
        } else {
            return 0;
        }
    }

    public static RAbstractVector expectImplicitRAbstractVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractVector((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractVector((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractVector((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractVector) {
            return (RAbstractVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Integer)
             || ((state & 0b10) != 0 && value instanceof Double)
             || ((state & 0b100) != 0 && value instanceof Byte)
             || ((state & 0b1000) != 0 && value instanceof String)
             || ((state & 0b10000) != 0 && value instanceof RAbstractVector);
    }

    public static RAbstractVector asImplicitRAbstractVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractVector((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractVector((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractVector((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractVector) {
            return (RAbstractVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractVector(Object value) {
        if (value instanceof Integer) {
            return 0b1;
        } else if (value instanceof Double) {
            return 0b10;
        } else if (value instanceof Byte) {
            return 0b100;
        } else if (value instanceof String) {
            return 0b1000;
        } else if (value instanceof RAbstractVector) {
            return 0b10000;
        } else {
            return 0;
        }
    }

    public static RAbstractStringVector expectImplicitRAbstractStringVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof String) {
            return toAbstractStringVector((String) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractStringVector) {
            return (RAbstractStringVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractStringVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof String)
             || ((state & 0b10) != 0 && value instanceof RAbstractStringVector);
    }

    public static RAbstractStringVector asImplicitRAbstractStringVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof String) {
            return toAbstractStringVector((String) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractStringVector) {
            return (RAbstractStringVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractStringVector(Object value) {
        if (value instanceof String) {
            return 0b1;
        } else if (value instanceof RAbstractStringVector) {
            return 0b10;
        } else {
            return 0;
        }
    }

    public static RAbstractLogicalVector expectImplicitRAbstractLogicalVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Byte) {
            return toAbstractLogicalVector((byte) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractLogicalVector) {
            return (RAbstractLogicalVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractLogicalVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Byte)
             || ((state & 0b10) != 0 && value instanceof RAbstractLogicalVector);
    }

    public static RAbstractLogicalVector asImplicitRAbstractLogicalVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Byte) {
            return toAbstractLogicalVector((byte) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractLogicalVector) {
            return (RAbstractLogicalVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractLogicalVector(Object value) {
        if (value instanceof Byte) {
            return 0b1;
        } else if (value instanceof RAbstractLogicalVector) {
            return 0b10;
        } else {
            return 0;
        }
    }

    public static RAbstractIntVector expectImplicitRAbstractIntVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractIntVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractIntVector) {
            return (RAbstractIntVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractIntVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Integer)
             || ((state & 0b10) != 0 && value instanceof RAbstractIntVector);
    }

    public static RAbstractIntVector asImplicitRAbstractIntVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractIntVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractIntVector) {
            return (RAbstractIntVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractIntVector(Object value) {
        if (value instanceof Integer) {
            return 0b1;
        } else if (value instanceof RAbstractIntVector) {
            return 0b10;
        } else {
            return 0;
        }
    }

    public static RAbstractDoubleVector expectImplicitRAbstractDoubleVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Double) {
            return toAbstractDoubleVector((double) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractDoubleVector) {
            return (RAbstractDoubleVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractDoubleVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Double)
             || ((state & 0b10) != 0 && value instanceof RAbstractDoubleVector);
    }

    public static RAbstractDoubleVector asImplicitRAbstractDoubleVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Double) {
            return toAbstractDoubleVector((double) value);
        } else if ((state & 0b10) != 0 && value instanceof RAbstractDoubleVector) {
            return (RAbstractDoubleVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractDoubleVector(Object value) {
        if (value instanceof Double) {
            return 0b1;
        } else if (value instanceof RAbstractDoubleVector) {
            return 0b10;
        } else {
            return 0;
        }
    }

    public static RAbstractContainer expectImplicitRAbstractContainer(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractContainer((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractContainer((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractContainer((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractContainer((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractContainer) {
            return (RAbstractContainer) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractContainer(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Integer)
             || ((state & 0b10) != 0 && value instanceof Double)
             || ((state & 0b100) != 0 && value instanceof Byte)
             || ((state & 0b1000) != 0 && value instanceof String)
             || ((state & 0b10000) != 0 && value instanceof RAbstractContainer);
    }

    public static RAbstractContainer asImplicitRAbstractContainer(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractContainer((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractContainer((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractContainer((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractContainer((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractContainer) {
            return (RAbstractContainer) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractContainer(Object value) {
        if (value instanceof Integer) {
            return 0b1;
        } else if (value instanceof Double) {
            return 0b10;
        } else if (value instanceof Byte) {
            return 0b100;
        } else if (value instanceof String) {
            return 0b1000;
        } else if (value instanceof RAbstractContainer) {
            return 0b10000;
        } else {
            return 0;
        }
    }

    public static RAbstractAtomicVector expectImplicitRAbstractAtomicVector(int state, Object value) throws UnexpectedResultException {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractAtomicVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractAtomicVector((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractAtomicVector((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractAtomicVector((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractAtomicVector) {
            return (RAbstractAtomicVector) value;
        } else {
            throw new UnexpectedResultException(value);
        }
    }

    public static boolean isImplicitRAbstractAtomicVector(int state, Object value) {
        return ((state & 0b1) != 0 && value instanceof Integer)
             || ((state & 0b10) != 0 && value instanceof Double)
             || ((state & 0b100) != 0 && value instanceof Byte)
             || ((state & 0b1000) != 0 && value instanceof String)
             || ((state & 0b10000) != 0 && value instanceof RAbstractAtomicVector);
    }

    public static RAbstractAtomicVector asImplicitRAbstractAtomicVector(int state, Object value) {
        if ((state & 0b1) != 0 && value instanceof Integer) {
            return toAbstractAtomicVector((int) value);
        } else if ((state & 0b10) != 0 && value instanceof Double) {
            return toAbstractAtomicVector((double) value);
        } else if ((state & 0b100) != 0 && value instanceof Byte) {
            return toAbstractAtomicVector((byte) value);
        } else if ((state & 0b1000) != 0 && value instanceof String) {
            return toAbstractAtomicVector((String) value);
        } else if ((state & 0b10000) != 0 && value instanceof RAbstractAtomicVector) {
            return (RAbstractAtomicVector) value;
        } else {
            CompilerDirectives.transferToInterpreterAndInvalidate();
            throw new IllegalArgumentException("Illegal type ");
        }
    }

    public static int specializeImplicitRAbstractAtomicVector(Object value) {
        if (value instanceof Integer) {
            return 0b1;
        } else if (value instanceof Double) {
            return 0b10;
        } else if (value instanceof Byte) {
            return 0b100;
        } else if (value instanceof String) {
            return 0b1000;
        } else if (value instanceof RAbstractAtomicVector) {
            return 0b10000;
        } else {
            return 0;
        }
    }

}
