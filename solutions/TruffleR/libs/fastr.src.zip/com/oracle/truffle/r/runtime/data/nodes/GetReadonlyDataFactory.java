// CheckStyle: start generated
package com.oracle.truffle.r.runtime.data.nodes;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.r.runtime.data.RDoubleVector;
import com.oracle.truffle.r.runtime.data.RIntVector;
import com.oracle.truffle.r.runtime.data.RList;
import com.oracle.truffle.r.runtime.data.model.RAbstractListVector;
import com.oracle.truffle.r.runtime.data.nodes.GetReadonlyData.Double;
import com.oracle.truffle.r.runtime.data.nodes.GetReadonlyData.Int;
import com.oracle.truffle.r.runtime.data.nodes.GetReadonlyData.ListData;
import java.util.concurrent.locks.Lock;

@GeneratedBy(GetReadonlyData.class)
public final class GetReadonlyDataFactory {

    @GeneratedBy(Double.class)
    public static final class DoubleNodeGen extends Double {

        @CompilationFinal private int state_ = 1;

        private DoubleNodeGen() {
        }

        @Override
        public double[] execute(RDoubleVector arg0Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active doManagedRVector(RDoubleVector) || doNativeDataRVector(RDoubleVector) */) {
                if ((state & 0b10) != 0 /* is-active doManagedRVector(RDoubleVector) */) {
                    if ((!(arg0Value.hasNativeMemoryData()))) {
                        return doManagedRVector(arg0Value);
                    }
                }
                if ((state & 0b100) != 0 /* is-active doNativeDataRVector(RDoubleVector) */) {
                    if ((arg0Value.hasNativeMemoryData())) {
                        return doNativeDataRVector(arg0Value);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private double[] executeAndSpecialize(RDoubleVector arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if ((!(arg0Value.hasNativeMemoryData()))) {
                    this.state_ = state | 0b10 /* add-active doManagedRVector(RDoubleVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doManagedRVector(arg0Value);
                }
                if ((arg0Value.hasNativeMemoryData())) {
                    this.state_ = state | 0b100 /* add-active doNativeDataRVector(RDoubleVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doNativeDataRVector(arg0Value);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static Double create() {
            return new DoubleNodeGen();
        }

    }
    @GeneratedBy(Int.class)
    public static final class IntNodeGen extends Int {

        @CompilationFinal private int state_ = 1;

        private IntNodeGen() {
        }

        @Override
        public int[] execute(RIntVector arg0Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active doManagedRVector(RIntVector) || doNativeDataRVector(RIntVector) */) {
                if ((state & 0b10) != 0 /* is-active doManagedRVector(RIntVector) */) {
                    if ((!(arg0Value.hasNativeMemoryData()))) {
                        return doManagedRVector(arg0Value);
                    }
                }
                if ((state & 0b100) != 0 /* is-active doNativeDataRVector(RIntVector) */) {
                    if ((arg0Value.hasNativeMemoryData())) {
                        return doNativeDataRVector(arg0Value);
                    }
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private int[] executeAndSpecialize(RIntVector arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if ((!(arg0Value.hasNativeMemoryData()))) {
                    this.state_ = state | 0b10 /* add-active doManagedRVector(RIntVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doManagedRVector(arg0Value);
                }
                if ((arg0Value.hasNativeMemoryData())) {
                    this.state_ = state | 0b100 /* add-active doNativeDataRVector(RIntVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doNativeDataRVector(arg0Value);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static Int create() {
            return new IntNodeGen();
        }

    }
    @GeneratedBy(ListData.class)
    public static final class ListDataNodeGen extends ListData {

        @CompilationFinal private int state_ = 1;

        private ListDataNodeGen() {
        }

        @Override
        public Object[] execute(RAbstractListVector arg0Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active doManagedRVector(RList) || doNativeDataRVector(RList) */ && arg0Value instanceof RList) {
                RList arg0Value_ = (RList) arg0Value;
                if ((state & 0b10) != 0 /* is-active doManagedRVector(RList) */) {
                    if ((!(arg0Value_.hasNativeMemoryData()))) {
                        return doManagedRVector(arg0Value_);
                    }
                }
                if ((state & 0b100) != 0 /* is-active doNativeDataRVector(RList) */) {
                    if ((arg0Value_.hasNativeMemoryData())) {
                        return doNativeDataRVector(arg0Value_);
                    }
                }
            }
            if ((state & 0b1000) != 0 /* is-active doGeneric(RAbstractListVector) */) {
                return doGeneric(arg0Value);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object[] executeAndSpecialize(RAbstractListVector arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof RList) {
                    RList arg0Value_ = (RList) arg0Value;
                    if ((!(arg0Value_.hasNativeMemoryData()))) {
                        this.state_ = state | 0b10 /* add-active doManagedRVector(RList) */;
                        lock.unlock();
                        hasLock = false;
                        return doManagedRVector(arg0Value_);
                    }
                    if ((arg0Value_.hasNativeMemoryData())) {
                        this.state_ = state | 0b100 /* add-active doNativeDataRVector(RList) */;
                        lock.unlock();
                        hasLock = false;
                        return doNativeDataRVector(arg0Value_);
                    }
                }
                this.state_ = state | 0b1000 /* add-active doGeneric(RAbstractListVector) */;
                lock.unlock();
                hasLock = false;
                return doGeneric(arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b1110) & ((state & 0b1110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static ListData create() {
            return new ListDataNodeGen();
        }

    }
}
