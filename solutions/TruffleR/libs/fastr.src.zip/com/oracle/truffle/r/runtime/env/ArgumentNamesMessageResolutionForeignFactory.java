// CheckStyle: start generated
package com.oracle.truffle.r.runtime.env;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.r.runtime.env.ArgumentNamesMessageResolutionForeign.ArgNamesGetSizeSubNode;
import com.oracle.truffle.r.runtime.env.ArgumentNamesMessageResolutionForeign.ArgNamesHasSizeSubNode;
import com.oracle.truffle.r.runtime.env.ArgumentNamesMessageResolutionForeign.ArgNamesReadSubNode;
import com.oracle.truffle.r.runtime.env.RScope.ArgumentNamesObject;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ArgumentNamesMessageResolutionForeign.class)
final class ArgumentNamesMessageResolutionForeignFactory {

    @GeneratedBy(ArgNamesReadSubNode.class)
    static final class ArgNamesReadSubNodeGen extends ArgNamesReadSubNode {

        @CompilationFinal private int state_ = 1;

        private ArgNamesReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ArgumentNamesObject, int) */ && arg0Value instanceof ArgumentNamesObject) {
                ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                if (arg1Value instanceof Integer) {
                    int arg1Value_ = (int) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ArgumentNamesObject) {
                    ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                    if (arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(ArgumentNamesObject, int) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ArgNamesReadSubNode create() {
            return new ArgNamesReadSubNodeGen();
        }

    }
    @GeneratedBy(ArgNamesGetSizeSubNode.class)
    static final class ArgNamesGetSizeSubNodeGen extends ArgNamesGetSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ArgNamesGetSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ArgumentNamesObject) */ && arg0Value instanceof ArgumentNamesObject) {
                ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ArgumentNamesObject) {
                    ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ArgumentNamesObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ArgNamesGetSizeSubNode create() {
            return new ArgNamesGetSizeSubNodeGen();
        }

    }
    @GeneratedBy(ArgNamesHasSizeSubNode.class)
    static final class ArgNamesHasSizeSubNodeGen extends ArgNamesHasSizeSubNode {

        @CompilationFinal private int state_ = 1;

        private ArgNamesHasSizeSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(ArgumentNamesObject) */ && arg0Value instanceof ArgumentNamesObject) {
                ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof ArgumentNamesObject) {
                    ArgumentNamesObject arg0Value_ = (ArgumentNamesObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(ArgumentNamesObject) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static ArgNamesHasSizeSubNode create() {
            return new ArgNamesHasSizeSubNodeGen();
        }

    }
}
