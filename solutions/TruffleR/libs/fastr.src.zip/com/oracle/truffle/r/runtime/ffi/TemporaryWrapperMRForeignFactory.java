// CheckStyle: start generated
package com.oracle.truffle.r.runtime.ffi;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.dsl.UnsupportedSpecializationException;
import com.oracle.truffle.api.frame.VirtualFrame;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.r.runtime.ffi.TemporaryWrapperMRForeign.TemporaryWrapperAsPointerSubNode;
import com.oracle.truffle.r.runtime.ffi.TemporaryWrapperMRForeign.TemporaryWrapperCheckSubNode;
import com.oracle.truffle.r.runtime.ffi.TemporaryWrapperMRForeign.TemporaryWrapperIsPointerSubNode;
import com.oracle.truffle.r.runtime.ffi.TemporaryWrapperMRForeign.TemporaryWrapperReadSubNode;
import com.oracle.truffle.r.runtime.ffi.TemporaryWrapperMRForeign.TemporaryWrapperWriteSubNode;
import java.util.concurrent.locks.Lock;

@GeneratedBy(TemporaryWrapperMRForeign.class)
final class TemporaryWrapperMRForeignFactory {

    @GeneratedBy(TemporaryWrapperWriteSubNode.class)
    public static final class TemporaryWrapperWriteSubNodeGen extends TemporaryWrapperWriteSubNode {

        @CompilationFinal private int state_ = 1;

        private TemporaryWrapperWriteSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value, Object arg2Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(TemporaryWrapper, long, Object) || accessWithTarget(TemporaryWrapper, int, Object) */ && arg0Value instanceof TemporaryWrapper) {
                TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(TemporaryWrapper, long, Object) */ && arg1Value instanceof Long) {
                    long arg1Value_ = (long) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(TemporaryWrapper, int, Object) */ && arg1Value instanceof Integer) {
                    int arg1Value_ = (int) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value, arg2Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value, Object arg2Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TemporaryWrapper) {
                    TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                    if (arg1Value instanceof Long) {
                        long arg1Value_ = (long) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(TemporaryWrapper, long, Object) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                    }
                    if (arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(TemporaryWrapper, int, Object) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_, arg2Value);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null, null}, arg0Value, arg1Value, arg2Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static TemporaryWrapperWriteSubNode create() {
            return new TemporaryWrapperWriteSubNodeGen();
        }

    }
    @GeneratedBy(TemporaryWrapperReadSubNode.class)
    public static final class TemporaryWrapperReadSubNodeGen extends TemporaryWrapperReadSubNode {

        @CompilationFinal private int state_ = 1;

        private TemporaryWrapperReadSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value, Object arg1Value) {
            int state = state_;
            if ((state & 0b110) != 0 /* is-active accessWithTarget(TemporaryWrapper, long) || accessWithTarget(TemporaryWrapper, int) */ && arg0Value instanceof TemporaryWrapper) {
                TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                if ((state & 0b10) != 0 /* is-active accessWithTarget(TemporaryWrapper, long) */ && arg1Value instanceof Long) {
                    long arg1Value_ = (long) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
                if ((state & 0b100) != 0 /* is-active accessWithTarget(TemporaryWrapper, int) */ && arg1Value instanceof Integer) {
                    int arg1Value_ = (int) arg1Value;
                    return accessWithTarget(arg0Value_, arg1Value_);
                }
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value, arg1Value);
        }

        private Object executeAndSpecialize(Object arg0Value, Object arg1Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TemporaryWrapper) {
                    TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                    if (arg1Value instanceof Long) {
                        long arg1Value_ = (long) arg1Value;
                        this.state_ = state | 0b10 /* add-active accessWithTarget(TemporaryWrapper, long) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                    if (arg1Value instanceof Integer) {
                        int arg1Value_ = (int) arg1Value;
                        this.state_ = state | 0b100 /* add-active accessWithTarget(TemporaryWrapper, int) */;
                        lock.unlock();
                        hasLock = false;
                        return accessWithTarget(arg0Value_, arg1Value_);
                    }
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null, null}, arg0Value, arg1Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else if (((state & 0b110) & ((state & 0b110) - 1)) == 0 /* is-single-active  */) {
                return NodeCost.MONOMORPHIC;
            }
            return NodeCost.POLYMORPHIC;
        }

        public static TemporaryWrapperReadSubNode create() {
            return new TemporaryWrapperReadSubNodeGen();
        }

    }
    @GeneratedBy(TemporaryWrapperAsPointerSubNode.class)
    public static final class TemporaryWrapperAsPointerSubNodeGen extends TemporaryWrapperAsPointerSubNode {

        @CompilationFinal private int state_ = 1;

        private TemporaryWrapperAsPointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TemporaryWrapper) */ && arg0Value instanceof TemporaryWrapper) {
                TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TemporaryWrapper) {
                    TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(TemporaryWrapper) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static TemporaryWrapperAsPointerSubNode create() {
            return new TemporaryWrapperAsPointerSubNodeGen();
        }

    }
    @GeneratedBy(TemporaryWrapperIsPointerSubNode.class)
    public static final class TemporaryWrapperIsPointerSubNodeGen extends TemporaryWrapperIsPointerSubNode {

        @CompilationFinal private int state_ = 1;

        private TemporaryWrapperIsPointerSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active accessWithTarget(TemporaryWrapper) */ && arg0Value instanceof TemporaryWrapper) {
                TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                return accessWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TemporaryWrapper) {
                    TemporaryWrapper arg0Value_ = (TemporaryWrapper) arg0Value;
                    this.state_ = state | 0b10 /* add-active accessWithTarget(TemporaryWrapper) */;
                    lock.unlock();
                    hasLock = false;
                    return accessWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static TemporaryWrapperIsPointerSubNode create() {
            return new TemporaryWrapperIsPointerSubNodeGen();
        }

    }
    @GeneratedBy(TemporaryWrapperCheckSubNode.class)
    public static final class TemporaryWrapperCheckSubNodeGen extends TemporaryWrapperCheckSubNode {

        @CompilationFinal private int state_ = 1;

        private TemporaryWrapperCheckSubNodeGen() {
        }

        @Override
        public Object executeWithTarget(VirtualFrame frameValue, Object arg0Value) {
            int state = state_;
            if ((state & 0b10) != 0 /* is-active testWithTarget(TruffleObject) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                return testWithTarget(arg0Value_);
            }
            CompilerDirectives.transferToInterpreterAndInvalidate();
            return executeAndSpecialize(arg0Value);
        }

        private Object executeAndSpecialize(Object arg0Value) {
            Lock lock = getLock();
            boolean hasLock = true;
            lock.lock();
            try {
                int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
                if (arg0Value instanceof TruffleObject) {
                    TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                    this.state_ = state | 0b10 /* add-active testWithTarget(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return testWithTarget(arg0Value_);
                }
                CompilerDirectives.transferToInterpreterAndInvalidate();
                throw new UnsupportedSpecializationException(this, new Node[] {null}, arg0Value);
            } finally {
                if (hasLock) {
                    lock.unlock();
                }
            }
        }

        @Override
        public NodeCost getCost() {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (state == 0b0) {
                return NodeCost.UNINITIALIZED;
            } else {
                return NodeCost.MONOMORPHIC;
            }
        }

        public static TemporaryWrapperCheckSubNode create() {
            return new TemporaryWrapperCheckSubNodeGen();
        }

    }
}
