// CheckStyle: start generated
package com.oracle.truffle.r.runtime.interop;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.r.runtime.RRuntime;
import java.util.concurrent.locks.Lock;

@GeneratedBy(Foreign2R.class)
public final class Foreign2RNodeGen extends Foreign2R {

    @CompilationFinal private int state_ = 1;

    private Foreign2RNodeGen() {
    }

    private boolean fallbackGuard_(int state, Object arg0Value) {
        if ((state & 0b10) == 0 /* is-not-active doBoolean(boolean) */ && arg0Value instanceof Boolean) {
            return false;
        }
        if ((state & 0b100) == 0 /* is-not-active doByte(byte) */ && arg0Value instanceof Byte) {
            return false;
        }
        if ((state & 0b1000) == 0 /* is-not-active doShort(short) */ && arg0Value instanceof Short) {
            return false;
        }
        if ((state & 0b10000) == 0 /* is-not-active doLong(long) */ && arg0Value instanceof Long) {
            return false;
        }
        if ((state & 0b100000) == 0 /* is-not-active doFloat(float) */ && arg0Value instanceof Float) {
            return false;
        }
        if ((state & 0b1000000) == 0 /* is-not-active doChar(char) */ && arg0Value instanceof Character) {
            return false;
        }
        if ((state & 0b10000000) == 0 /* is-not-active doNull(Object) */ && (isNull(arg0Value))) {
            return false;
        }
        if (arg0Value instanceof TruffleObject) {
            TruffleObject arg0Value_ = (TruffleObject) arg0Value;
            if ((RRuntime.isForeignObject(arg0Value_))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Object execute(Object arg0Value) {
        int state = state_;
        if ((state & 0b10) != 0 /* is-active doBoolean(boolean) */ && arg0Value instanceof Boolean) {
            boolean arg0Value_ = (boolean) arg0Value;
            return doBoolean(arg0Value_);
        }
        if ((state & 0b100) != 0 /* is-active doByte(byte) */ && arg0Value instanceof Byte) {
            byte arg0Value_ = (byte) arg0Value;
            return doByte(arg0Value_);
        }
        if ((state & 0b1000) != 0 /* is-active doShort(short) */ && arg0Value instanceof Short) {
            short arg0Value_ = (short) arg0Value;
            return doShort(arg0Value_);
        }
        if ((state & 0b10000) != 0 /* is-active doLong(long) */ && arg0Value instanceof Long) {
            long arg0Value_ = (long) arg0Value;
            return doLong(arg0Value_);
        }
        if ((state & 0b100000) != 0 /* is-active doFloat(float) */ && arg0Value instanceof Float) {
            float arg0Value_ = (float) arg0Value;
            return doFloat(arg0Value_);
        }
        if ((state & 0b1000000) != 0 /* is-active doChar(char) */ && arg0Value instanceof Character) {
            char arg0Value_ = (char) arg0Value;
            return doChar(arg0Value_);
        }
        if ((state & 0b10000000) != 0 /* is-active doNull(Object) */) {
            if ((isNull(arg0Value))) {
                return doNull(arg0Value);
            }
        }
        if ((state & 0b100000000) != 0 /* is-active doForeignObject(TruffleObject) */ && arg0Value instanceof TruffleObject) {
            TruffleObject arg0Value_ = (TruffleObject) arg0Value;
            if ((RRuntime.isForeignObject(arg0Value_))) {
                return doForeignObject(arg0Value_);
            }
        }
        if ((state & 0b1000000000) != 0 /* is-active doObject(Object) */) {
            if (fallbackGuard_(state, arg0Value)) {
                return doObject(arg0Value);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value);
    }

    private Object executeAndSpecialize(Object arg0Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (arg0Value instanceof Boolean) {
                boolean arg0Value_ = (boolean) arg0Value;
                this.state_ = state | 0b10 /* add-active doBoolean(boolean) */;
                lock.unlock();
                hasLock = false;
                return doBoolean(arg0Value_);
            }
            if (arg0Value instanceof Byte) {
                byte arg0Value_ = (byte) arg0Value;
                this.state_ = state | 0b100 /* add-active doByte(byte) */;
                lock.unlock();
                hasLock = false;
                return doByte(arg0Value_);
            }
            if (arg0Value instanceof Short) {
                short arg0Value_ = (short) arg0Value;
                this.state_ = state | 0b1000 /* add-active doShort(short) */;
                lock.unlock();
                hasLock = false;
                return doShort(arg0Value_);
            }
            if (arg0Value instanceof Long) {
                long arg0Value_ = (long) arg0Value;
                this.state_ = state | 0b10000 /* add-active doLong(long) */;
                lock.unlock();
                hasLock = false;
                return doLong(arg0Value_);
            }
            if (arg0Value instanceof Float) {
                float arg0Value_ = (float) arg0Value;
                this.state_ = state | 0b100000 /* add-active doFloat(float) */;
                lock.unlock();
                hasLock = false;
                return doFloat(arg0Value_);
            }
            if (arg0Value instanceof Character) {
                char arg0Value_ = (char) arg0Value;
                this.state_ = state | 0b1000000 /* add-active doChar(char) */;
                lock.unlock();
                hasLock = false;
                return doChar(arg0Value_);
            }
            if ((isNull(arg0Value))) {
                this.state_ = state | 0b10000000 /* add-active doNull(Object) */;
                lock.unlock();
                hasLock = false;
                return doNull(arg0Value);
            }
            if (arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                if ((RRuntime.isForeignObject(arg0Value_))) {
                    this.state_ = state | 0b100000000 /* add-active doForeignObject(TruffleObject) */;
                    lock.unlock();
                    hasLock = false;
                    return doForeignObject(arg0Value_);
                }
            }
            this.state_ = state | 0b1000000000 /* add-active doObject(Object) */;
            lock.unlock();
            hasLock = false;
            return doObject(arg0Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0b1111111110) & ((state & 0b1111111110) - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static Foreign2R create() {
        return new Foreign2RNodeGen();
    }

}
