// CheckStyle: start generated
package com.oracle.truffle.r.runtime.interop;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.interop.Message;
import com.oracle.truffle.api.interop.TruffleObject;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.NodeCost;
import java.util.concurrent.locks.Lock;

@GeneratedBy(ForeignArray2R.class)
public final class ForeignArray2RNodeGen extends ForeignArray2R {

    @CompilationFinal private int state_ = 1;
    @Child private Node javaIterable_execute_;

    private ForeignArray2RNodeGen() {
    }

    @SuppressWarnings("unused")
    private boolean fallbackGuard_(Object arg0Value, boolean arg1Value, ForeignArrayData arg2Value, int arg3Value) {
        if (arg0Value instanceof TruffleObject) {
            {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                if ((isForeignArray(arg0Value_))) {
                    return false;
                }
            }
            {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                if ((ForeignArray2R.isJavaIterable(arg0Value_))) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    protected Object execute(Object arg0Value, boolean arg1Value, ForeignArrayData arg2Value, int arg3Value) {
        int state = state_;
        if ((state & 0b1110) != 0 /* is-active doArray(TruffleObject, boolean, ForeignArrayData, int) || doJavaIterable(TruffleObject, boolean, ForeignArrayData, int, Node) || doObject(Object, boolean, ForeignArrayData, int) */) {
            if ((state & 0b110) != 0 /* is-active doArray(TruffleObject, boolean, ForeignArrayData, int) || doJavaIterable(TruffleObject, boolean, ForeignArrayData, int, Node) */ && arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                if ((state & 0b10) != 0 /* is-active doArray(TruffleObject, boolean, ForeignArrayData, int) */) {
                    if ((isForeignArray(arg0Value_))) {
                        return doArray(arg0Value_, arg1Value, arg2Value, arg3Value);
                    }
                }
                if ((state & 0b100) != 0 /* is-active doJavaIterable(TruffleObject, boolean, ForeignArrayData, int, Node) */) {
                    if ((ForeignArray2R.isJavaIterable(arg0Value_))) {
                        return doJavaIterable(arg0Value_, arg1Value, arg2Value, arg3Value, javaIterable_execute_);
                    }
                }
            }
            if ((state & 0b1000) != 0 /* is-active doObject(Object, boolean, ForeignArrayData, int) */) {
                if (fallbackGuard_(arg0Value, arg1Value, arg2Value, arg3Value)) {
                    return doObject(arg0Value, arg1Value, arg2Value, arg3Value);
                }
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value, arg1Value, arg2Value, arg3Value);
    }

    private Object executeAndSpecialize(Object arg0Value, boolean arg1Value, ForeignArrayData arg2Value, int arg3Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (arg0Value instanceof TruffleObject) {
                TruffleObject arg0Value_ = (TruffleObject) arg0Value;
                if ((isForeignArray(arg0Value_))) {
                    this.state_ = state | 0b10 /* add-active doArray(TruffleObject, boolean, ForeignArrayData, int) */;
                    lock.unlock();
                    hasLock = false;
                    return doArray(arg0Value_, arg1Value, arg2Value, arg3Value);
                }
                if ((ForeignArray2R.isJavaIterable(arg0Value_))) {
                    this.javaIterable_execute_ = super.insert((Message.createExecute(0).createNode()));
                    this.state_ = state | 0b100 /* add-active doJavaIterable(TruffleObject, boolean, ForeignArrayData, int, Node) */;
                    lock.unlock();
                    hasLock = false;
                    return doJavaIterable(arg0Value_, arg1Value, arg2Value, arg3Value, javaIterable_execute_);
                }
            }
            this.state_ = state | 0b1000 /* add-active doObject(Object, boolean, ForeignArrayData, int) */;
            lock.unlock();
            hasLock = false;
            return doObject(arg0Value, arg1Value, arg2Value, arg3Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0b1110) & ((state & 0b1110) - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static ForeignArray2R create() {
        return new ForeignArray2RNodeGen();
    }

}
