// CheckStyle: start generated
package com.oracle.truffle.r.runtime.interop;

import com.oracle.truffle.api.CompilerDirectives;
import com.oracle.truffle.api.CompilerDirectives.CompilationFinal;
import com.oracle.truffle.api.dsl.GeneratedBy;
import com.oracle.truffle.api.nodes.NodeCost;
import com.oracle.truffle.r.runtime.data.RRaw;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropByte;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropChar;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropFloat;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropLong;
import com.oracle.truffle.r.runtime.data.RInteropScalar.RInteropShort;
import com.oracle.truffle.r.runtime.data.model.RAbstractDoubleVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractIntVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractLogicalVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractRawVector;
import com.oracle.truffle.r.runtime.data.model.RAbstractStringVector;
import java.util.concurrent.locks.Lock;

@GeneratedBy(R2Foreign.class)
public final class R2ForeignNodeGen extends R2Foreign {

    @CompilationFinal private int state_ = 1;

    private R2ForeignNodeGen() {
    }

    private boolean fallbackGuard_(int state, Object arg0Value) {
        if ((state & 0b10) == 0 /* is-not-active doByte(byte) */ && arg0Value instanceof Byte) {
            return false;
        }
        if ((state & 0b100) == 0 /* is-not-active doDouble(double) */ && arg0Value instanceof Double) {
            return false;
        }
        if ((state & 0b1000) == 0 /* is-not-active doInt(int) */ && arg0Value instanceof Integer) {
            return false;
        }
        if ((state & 0b10000) == 0 /* is-not-active doString(String) */ && arg0Value instanceof String) {
            return false;
        }
        if ((state & 0b100000) == 0 /* is-not-active doRaw(RRaw) */ && arg0Value instanceof RRaw) {
            return false;
        }
        if (arg0Value instanceof RAbstractDoubleVector) {
            RAbstractDoubleVector arg0Value_ = (RAbstractDoubleVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return false;
            }
        }
        if (arg0Value instanceof RAbstractIntVector) {
            RAbstractIntVector arg0Value_ = (RAbstractIntVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return false;
            }
        }
        if (arg0Value instanceof RAbstractLogicalVector) {
            RAbstractLogicalVector arg0Value_ = (RAbstractLogicalVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return false;
            }
        }
        if (arg0Value instanceof RAbstractRawVector) {
            RAbstractRawVector arg0Value_ = (RAbstractRawVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return false;
            }
        }
        if (arg0Value instanceof RAbstractStringVector) {
            RAbstractStringVector arg0Value_ = (RAbstractStringVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return false;
            }
        }
        if ((state & 0b100000000000) == 0 /* is-not-active doInteroptByte(RInteropByte) */ && arg0Value instanceof RInteropByte) {
            return false;
        }
        if ((state & 0b1000000000000) == 0 /* is-not-active doInteroptChar(RInteropChar) */ && arg0Value instanceof RInteropChar) {
            return false;
        }
        if ((state & 0b10000000000000) == 0 /* is-not-active doInteroptFloat(RInteropFloat) */ && arg0Value instanceof RInteropFloat) {
            return false;
        }
        if ((state & 0b100000000000000) == 0 /* is-not-active doInteroptLong(RInteropLong) */ && arg0Value instanceof RInteropLong) {
            return false;
        }
        if ((state & 0b1000000000000000) == 0 /* is-not-active doInteroptShort(RInteropShort) */ && arg0Value instanceof RInteropShort) {
            return false;
        }
        return true;
    }

    @Override
    public Object execute(Object arg0Value) {
        int state = state_;
        if ((state & 0b10) != 0 /* is-active doByte(byte) */ && arg0Value instanceof Byte) {
            byte arg0Value_ = (byte) arg0Value;
            return doByte(arg0Value_);
        }
        if ((state & 0b100) != 0 /* is-active doDouble(double) */ && arg0Value instanceof Double) {
            double arg0Value_ = (double) arg0Value;
            return doDouble(arg0Value_);
        }
        if ((state & 0b1000) != 0 /* is-active doInt(int) */ && arg0Value instanceof Integer) {
            int arg0Value_ = (int) arg0Value;
            return doInt(arg0Value_);
        }
        if ((state & 0b10000) != 0 /* is-active doString(String) */ && arg0Value instanceof String) {
            String arg0Value_ = (String) arg0Value;
            return doString(arg0Value_);
        }
        if ((state & 0b100000) != 0 /* is-active doRaw(RRaw) */ && arg0Value instanceof RRaw) {
            RRaw arg0Value_ = (RRaw) arg0Value;
            return doRaw(arg0Value_);
        }
        if ((state & 0b1000000) != 0 /* is-active doDoubleVector(RAbstractDoubleVector) */ && arg0Value instanceof RAbstractDoubleVector) {
            RAbstractDoubleVector arg0Value_ = (RAbstractDoubleVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return doDoubleVector(arg0Value_);
            }
        }
        if ((state & 0b10000000) != 0 /* is-active doIntVector(RAbstractIntVector) */ && arg0Value instanceof RAbstractIntVector) {
            RAbstractIntVector arg0Value_ = (RAbstractIntVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return doIntVector(arg0Value_);
            }
        }
        if ((state & 0b100000000) != 0 /* is-active doLogicalVector(RAbstractLogicalVector) */ && arg0Value instanceof RAbstractLogicalVector) {
            RAbstractLogicalVector arg0Value_ = (RAbstractLogicalVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return doLogicalVector(arg0Value_);
            }
        }
        if ((state & 0b1000000000) != 0 /* is-active doRawVector(RAbstractRawVector) */ && arg0Value instanceof RAbstractRawVector) {
            RAbstractRawVector arg0Value_ = (RAbstractRawVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return doRawVector(arg0Value_);
            }
        }
        if ((state & 0b10000000000) != 0 /* is-active doStringVector(RAbstractStringVector) */ && arg0Value instanceof RAbstractStringVector) {
            RAbstractStringVector arg0Value_ = (RAbstractStringVector) arg0Value;
            if ((arg0Value_.getLength() == 1)) {
                return doStringVector(arg0Value_);
            }
        }
        if ((state & 0b100000000000) != 0 /* is-active doInteroptByte(RInteropByte) */ && arg0Value instanceof RInteropByte) {
            RInteropByte arg0Value_ = (RInteropByte) arg0Value;
            return doInteroptByte(arg0Value_);
        }
        if ((state & 0b1000000000000) != 0 /* is-active doInteroptChar(RInteropChar) */ && arg0Value instanceof RInteropChar) {
            RInteropChar arg0Value_ = (RInteropChar) arg0Value;
            return doInteroptChar(arg0Value_);
        }
        if ((state & 0b10000000000000) != 0 /* is-active doInteroptFloat(RInteropFloat) */ && arg0Value instanceof RInteropFloat) {
            RInteropFloat arg0Value_ = (RInteropFloat) arg0Value;
            return doInteroptFloat(arg0Value_);
        }
        if ((state & 0b100000000000000) != 0 /* is-active doInteroptLong(RInteropLong) */ && arg0Value instanceof RInteropLong) {
            RInteropLong arg0Value_ = (RInteropLong) arg0Value;
            return doInteroptLong(arg0Value_);
        }
        if ((state & 0b1000000000000000) != 0 /* is-active doInteroptShort(RInteropShort) */ && arg0Value instanceof RInteropShort) {
            RInteropShort arg0Value_ = (RInteropShort) arg0Value;
            return doInteroptShort(arg0Value_);
        }
        if ((state & 0x10000) != 0 /* is-active doObject(Object) */) {
            if (fallbackGuard_(state, arg0Value)) {
                return R2Foreign.doObject(arg0Value);
            }
        }
        CompilerDirectives.transferToInterpreterAndInvalidate();
        return executeAndSpecialize(arg0Value);
    }

    private Object executeAndSpecialize(Object arg0Value) {
        Lock lock = getLock();
        boolean hasLock = true;
        lock.lock();
        try {
            int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
            if (arg0Value instanceof Byte) {
                byte arg0Value_ = (byte) arg0Value;
                this.state_ = state | 0b10 /* add-active doByte(byte) */;
                lock.unlock();
                hasLock = false;
                return doByte(arg0Value_);
            }
            if (arg0Value instanceof Double) {
                double arg0Value_ = (double) arg0Value;
                this.state_ = state | 0b100 /* add-active doDouble(double) */;
                lock.unlock();
                hasLock = false;
                return doDouble(arg0Value_);
            }
            if (arg0Value instanceof Integer) {
                int arg0Value_ = (int) arg0Value;
                this.state_ = state | 0b1000 /* add-active doInt(int) */;
                lock.unlock();
                hasLock = false;
                return doInt(arg0Value_);
            }
            if (arg0Value instanceof String) {
                String arg0Value_ = (String) arg0Value;
                this.state_ = state | 0b10000 /* add-active doString(String) */;
                lock.unlock();
                hasLock = false;
                return doString(arg0Value_);
            }
            if (arg0Value instanceof RRaw) {
                RRaw arg0Value_ = (RRaw) arg0Value;
                this.state_ = state | 0b100000 /* add-active doRaw(RRaw) */;
                lock.unlock();
                hasLock = false;
                return doRaw(arg0Value_);
            }
            if (arg0Value instanceof RAbstractDoubleVector) {
                RAbstractDoubleVector arg0Value_ = (RAbstractDoubleVector) arg0Value;
                if ((arg0Value_.getLength() == 1)) {
                    this.state_ = state | 0b1000000 /* add-active doDoubleVector(RAbstractDoubleVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doDoubleVector(arg0Value_);
                }
            }
            if (arg0Value instanceof RAbstractIntVector) {
                RAbstractIntVector arg0Value_ = (RAbstractIntVector) arg0Value;
                if ((arg0Value_.getLength() == 1)) {
                    this.state_ = state | 0b10000000 /* add-active doIntVector(RAbstractIntVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doIntVector(arg0Value_);
                }
            }
            if (arg0Value instanceof RAbstractLogicalVector) {
                RAbstractLogicalVector arg0Value_ = (RAbstractLogicalVector) arg0Value;
                if ((arg0Value_.getLength() == 1)) {
                    this.state_ = state | 0b100000000 /* add-active doLogicalVector(RAbstractLogicalVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doLogicalVector(arg0Value_);
                }
            }
            if (arg0Value instanceof RAbstractRawVector) {
                RAbstractRawVector arg0Value_ = (RAbstractRawVector) arg0Value;
                if ((arg0Value_.getLength() == 1)) {
                    this.state_ = state | 0b1000000000 /* add-active doRawVector(RAbstractRawVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doRawVector(arg0Value_);
                }
            }
            if (arg0Value instanceof RAbstractStringVector) {
                RAbstractStringVector arg0Value_ = (RAbstractStringVector) arg0Value;
                if ((arg0Value_.getLength() == 1)) {
                    this.state_ = state | 0b10000000000 /* add-active doStringVector(RAbstractStringVector) */;
                    lock.unlock();
                    hasLock = false;
                    return doStringVector(arg0Value_);
                }
            }
            if (arg0Value instanceof RInteropByte) {
                RInteropByte arg0Value_ = (RInteropByte) arg0Value;
                this.state_ = state | 0b100000000000 /* add-active doInteroptByte(RInteropByte) */;
                lock.unlock();
                hasLock = false;
                return doInteroptByte(arg0Value_);
            }
            if (arg0Value instanceof RInteropChar) {
                RInteropChar arg0Value_ = (RInteropChar) arg0Value;
                this.state_ = state | 0b1000000000000 /* add-active doInteroptChar(RInteropChar) */;
                lock.unlock();
                hasLock = false;
                return doInteroptChar(arg0Value_);
            }
            if (arg0Value instanceof RInteropFloat) {
                RInteropFloat arg0Value_ = (RInteropFloat) arg0Value;
                this.state_ = state | 0b10000000000000 /* add-active doInteroptFloat(RInteropFloat) */;
                lock.unlock();
                hasLock = false;
                return doInteroptFloat(arg0Value_);
            }
            if (arg0Value instanceof RInteropLong) {
                RInteropLong arg0Value_ = (RInteropLong) arg0Value;
                this.state_ = state | 0b100000000000000 /* add-active doInteroptLong(RInteropLong) */;
                lock.unlock();
                hasLock = false;
                return doInteroptLong(arg0Value_);
            }
            if (arg0Value instanceof RInteropShort) {
                RInteropShort arg0Value_ = (RInteropShort) arg0Value;
                this.state_ = state | 0b1000000000000000 /* add-active doInteroptShort(RInteropShort) */;
                lock.unlock();
                hasLock = false;
                return doInteroptShort(arg0Value_);
            }
            this.state_ = state | 0x10000 /* add-active doObject(Object) */;
            lock.unlock();
            hasLock = false;
            return R2Foreign.doObject(arg0Value);
        } finally {
            if (hasLock) {
                lock.unlock();
            }
        }
    }

    @Override
    public NodeCost getCost() {
        int state = state_ & 0xfffffffe/* mask-active uninitialized*/;
        if (state == 0b0) {
            return NodeCost.UNINITIALIZED;
        } else if (((state & 0x1fffe) & ((state & 0x1fffe) - 1)) == 0 /* is-single-active  */) {
            return NodeCost.MONOMORPHIC;
        }
        return NodeCost.POLYMORPHIC;
    }

    public static R2Foreign create() {
        return new R2ForeignNodeGen();
    }

}
