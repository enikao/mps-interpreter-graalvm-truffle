package jnr.posix;

import jnr.ffi.Pointer;

public interface NSGetEnviron {

    Pointer _NSGetEnviron();

}
